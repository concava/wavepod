import sys, subprocess
out, files = sys.argv[1], sys.argv[2:]
n = len(files); cols = 3
inputs = sum((['-i', f] for f in files), [])
chain = ''.join(f'[{i}]scale=640:360[v{i}];' for i in range(n))
layout = '|'.join(f'{(k%cols)*640}_{(k//cols)*360}' for k in range(n))
chain += ''.join(f'[v{i}]' for i in range(n)) + f'xstack=inputs={n}:layout={layout}:fill=red'
subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-y', *inputs, '-filter_complex', chain, out], check=True)
