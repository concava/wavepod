#!/bin/zsh
# Normalizes the mix to -16 LUFS / -1.5 dBTP (two-pass loudnorm) and encodes the final H.264 film with the soundtrack.
set -e
cd "${0:A:h}"
stats=$(ffmpeg -nostdin -hide_banner -i mix.wav -af loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json -f null - 2>&1 | sed -n '/^{/,/^}/p')
get() { echo "$stats" | python3 -c "import json,sys; print(json.load(sys.stdin)['$1'])"; }
ffmpeg -nostdin -v error -y -i mix.wav -af "loudnorm=I=-16:TP=-1.5:LRA=11:measured_I=$(get input_i):measured_TP=$(get input_tp):measured_LRA=$(get input_lra):measured_thresh=$(get input_thresh):offset=$(get target_offset):linear=true,aresample=48000" -c:a pcm_s24le mix-master.wav
ffmpeg -nostdin -v error -y -i film-silent.mov -i mix-master.wav -map 0:v -map 1:a \
  -c:v libx264 -preset slow -crf 15 -profile:v high -pix_fmt yuv420p -tune film \
  -color_primaries bt709 -color_trc bt709 -colorspace bt709 -x264-params "keyint=120:min-keyint=60" \
  -c:a aac -b:a 256k -ar 48000 -movflags +faststart -shortest wavepod-launch-30s.mp4
ffmpeg -nostdin -v error -y -ss 29.5 -i film-silent.mov -frames:v 1 -q:v 2 wavepod-launch-poster.jpg
ls -la wavepod-launch-30s.mp4 wavepod-launch-poster.jpg
