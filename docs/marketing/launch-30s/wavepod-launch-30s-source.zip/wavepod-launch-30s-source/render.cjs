// Renders the film with headless Chrome: each frame is render(t) followed by a screenshot.
//   node render.cjs --stills 1.2,8.9,...     PNG stills in stills/
//   node render.cjs --video [--fps 60] [--workers 6] [--from 0 --to 30]   video segments, joined into film-silent.mov
//   node render.cjs --cues                    writes cues.json for the audio script
const puppeteer = require('puppeteer-core');
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf('--' + k); return i < 0 ? d : args[i + 1]; };
const has = k => args.includes('--' + k);
const CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const URL = 'file://' + path.join(__dirname, 'index.html');

async function openPage(browser) {
  const page = await browser.newPage();
  await page.setViewport({ width: 1920, height: 1080, deviceScaleFactor: 1 });
  page.on('pageerror', e => console.error('page error:', e.message));
  page.on('console', m => { if (m.type() === 'error') console.error('console:', m.text()); });
  await page.goto(URL, { waitUntil: 'load' });
  await page.evaluate(() => window.READY);
  return page;
}
const launch = () => puppeteer.launch({
  executablePath: CHROME, headless: true, protocolTimeout: 900000,
  args: ['--allow-file-access-from-files', '--force-color-profile=srgb', '--hide-scrollbars', '--disable-lcd-text', '--font-render-hinting=none'],
});

async function stills(list) {
  const browser = await launch();
  const page = await openPage(browser);
  fs.mkdirSync(path.join(__dirname, 'stills'), { recursive: true });
  for (const t of list) {
    await page.evaluate(t => window.render(t), t);
    await page.screenshot({ path: path.join(__dirname, 'stills', `t${t.toFixed(2).padStart(5, '0')}.png`) });
  }
  await browser.close();
}

async function video() {
  const fps = +opt('fps', 60), workers = +opt('workers', 6);
  const from = +opt('from', 0), to = +opt('to', 30);
  const first = Math.round(from * fps), last = Math.round(to * fps);
  const total = last - first, per = Math.ceil(total / workers);
  const dir = path.join(__dirname, 'segments'); fs.mkdirSync(dir, { recursive: true });
  const started = Date.now();
  let done = 0;
  // One browser per worker: pages that share a browser queue behind each other's screenshots.
  const jobs = [...Array(workers).keys()].map(async w => {
    const a = first + w * per, b = Math.min(last, a + per);
    if (a >= b) return null;
    const browser = await launch();
    const page = await openPage(browser);
    const file = path.join(dir, `seg${String(w).padStart(2, '0')}.mov`);
    const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', String(fps), '-c:v', 'png', '-i', '-',
      '-c:v', 'prores_ks', '-profile:v', '3', '-pix_fmt', 'yuv422p10le', '-vendor', 'apl0', file], { stdio: ['pipe', 'inherit', 'inherit'] });
    for (let f = a; f < b; f++) {
      await page.evaluate(t => window.render(t), f / fps);
      const buf = await page.screenshot({ type: 'png', optimizeForSpeed: true });
      if (!ff.stdin.write(buf)) await new Promise(r => ff.stdin.once('drain', r));
      if (++done % 60 === 0) process.stdout.write(`\r${done}/${total} frames, ${((Date.now() - started) / 1000).toFixed(0)} s`);
    }
    ff.stdin.end();
    await new Promise(r => ff.on('close', r));
    await browser.close();
    return file;
  });
  const files = (await Promise.all(jobs)).filter(Boolean);
  fs.writeFileSync(path.join(dir, 'list.txt'), files.map(f => `file '${f}'`).join('\n'));
  await new Promise(r => spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', path.join(dir, 'list.txt'), '-c', 'copy', path.join(__dirname, 'film-silent.mov')], { stdio: 'inherit' }).on('close', r));
  console.log(`\nrendered ${total} frames in ${((Date.now() - started) / 1000).toFixed(0)} s`);
}

async function cues() {
  const browser = await launch();
  const page = await openPage(browser);
  const c = await page.evaluate(() => window.CUES);
  fs.writeFileSync(path.join(__dirname, 'cues.json'), JSON.stringify(c.sort((a, b) => a.t - b.t), null, 0));
  console.log(c.length, 'cues');
  await browser.close();
}

(async () => {
  if (has('stills')) await stills(opt('stills').split(',').map(Number));
  else if (has('video')) await video();
  else if (has('cues')) await cues();
})().catch(e => { console.error(e); process.exit(1); });
