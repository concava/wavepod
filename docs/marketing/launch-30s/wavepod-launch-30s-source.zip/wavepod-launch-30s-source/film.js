'use strict';
// Wavepod launch film. render(t) draws the frame at t seconds from scratch, so any frame can be rendered alone.
const W = 1920, H = 1080, DURATION = 30;

// ---------- Math ----------
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, p) => a + (b - a) * p;
function bezier(x1, y1, x2, y2) {
  const cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx;
  const cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
  const sx = t => ((ax * t + bx) * t + cx) * t, sy = t => ((ay * t + by) * t + cy) * t;
  return x => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    let lo = 0, hi = 1, t = x;
    for (let i = 0; i < 40; i++) { const v = sx(t); if (Math.abs(v - x) < 1e-6) break; if (v < x) lo = t; else hi = t; t = (lo + hi) / 2; }
    return sy(t);
  };
}
// One signature curve (the app's Motion.standard) for things that move into place, a slower in-out for the camera.
const E = {
  std: bezier(0.2, 0, 0, 1),
  inOut: bezier(0.4, 0, 0.2, 1),
  cam: bezier(0.65, 0, 0.35, 1),
  out: bezier(0.16, 1, 0.3, 1),
  in: bezier(0.55, 0, 1, 0.45),
  lin: x => x,
};
const P = (t, a, b, e = E.std) => e(clamp((t - a) / (b - a)));
function rng(seed) { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const fmt = s => { const tot = Math.floor(Math.max(0, s)); const h = Math.floor(tot / 3600), m = Math.floor(tot % 3600 / 60), sec = tot % 60; const p = n => String(n).padStart(2, '0'); return h > 0 ? `${h}:${p(m)}:${p(sec)}` : `${p(m)}:${p(sec)}`; };

// ---------- DOM ----------
const stage = document.getElementById('stage');
function h(tag, cls, parent, css, html) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (css) for (const k in css) e.style[k] = typeof css[k] === 'number' && !/opacity|zIndex|fontWeight|lineHeight/.test(k) ? css[k] + 'px' : css[k];
  if (html != null) e.innerHTML = html;
  (parent || stage).appendChild(e);
  return e;
}
function put(el, o = {}) {
  const { o: op = 1, x = 0, y = 0, s = 1, sx, sy, r = 0, blur = 0 } = o;
  el.style.opacity = op;
  el.style.visibility = op <= 0.002 ? 'hidden' : 'visible';
  el.style.transform = `translate(${x.toFixed(2)}px,${y.toFixed(2)}px) rotate(${r.toFixed(3)}deg) scale(${(sx ?? s).toFixed(4)},${(sy ?? s).toFixed(4)})`;
  el.style.filter = blur > 0.05 ? `blur(${blur.toFixed(2)}px)` : 'none';
}
// An entrance (rise, sharpen, fade in) and an optional shorter exit, as put() parameters.
function ap(t, tin, i = {}, tout = 1e9, x = {}) {
  const { dur = 0.5, y = 16, dx = 0, blur = 12, s = 1, ease = E.out } = i;
  const { dur: od = 0.22, y: oy = -12, dx: ox = 0, blur: ob = 8, s: os = 1 } = x;
  const pi = ease(clamp((t - tin) / dur)), po = E.in(clamp((t - tout) / od));
  return { o: pi * (1 - po), x: lerp(dx, 0, pi) + ox * po, y: lerp(y, 0, pi) + oy * po, blur: lerp(blur, 0, pi) + ob * po, s: lerp(s, 1, pi) * lerp(1, os, po) };
}
const rectOf = el => el.getBoundingClientRect();
const centerOf = el => { const r = rectOf(el); return [r.left + r.width / 2, r.top + r.height / 2]; };

// ---------- Sound cues, read by the audio script ----------
window.CUES = [];
const cue = (type, t, extra = {}) => window.CUES.push({ type, t: +t.toFixed(4), ...extra });

// ---------- Typing ----------
function typeTimes(text, t0, cps, seed = 1, sound = 'key') {
  const r = rng(seed), out = [];
  let t = t0;
  for (const c of text) { out.push(t); let d = (1 / cps) * (0.55 + r() * 0.9); if (c === ' ') d *= 1.15; if (/[,.?!]/.test(c)) d *= 2; t += d; }
  if (sound) out.forEach((x, i) => cue(sound, x, { ch: text[i] }));
  return out;
}
const countAt = (tt, t) => { let n = 0; while (n < tt.length && tt[n] <= t) n++; return n; };
const blinkOn = (t, since) => t < since || Math.floor((t - since) / 0.53) % 2 === 0;

// ---------- Text roll: the old line leaves upwards, the new one rises in ----------
function makeRoll(parent, items, css = {}) {
  const box = h('span', 'roll', parent, css);
  const a = h('span', '', box), b = h('span', '', box);
  return { box, a, b, items };
}
function rollAt(R, t, dist = 26, dur = 0.28) {
  let i = -1;
  for (let k = 0; k < R.items.length; k++) if (R.items[k].t <= t) i = k;
  if (i < 0) { R.a.style.visibility = R.b.style.visibility = 'hidden'; return 0; }
  const p = E.std(clamp((t - R.items[i].t) / dur));
  if (R.a.textContent !== R.items[i].text) R.a.textContent = R.items[i].text;
  put(R.a, { o: p, y: (1 - p) * dist, blur: (1 - p) * 6 });
  if (i > 0 && p < 1) { if (R.b.textContent !== R.items[i - 1].text) R.b.textContent = R.items[i - 1].text; put(R.b, { o: 1 - p, y: -p * dist, blur: p * 6 }); }
  else R.b.style.visibility = 'hidden';
  return i;
}

// ---------- Scenes ----------
const scenes = [];
function scene(t0, t1, css) { const root = h('div', 'scene', stage, css); const sc = { t0, t1, root, update() {} }; scenes.push(sc); return sc; }
const measures = [];
const onMeasure = f => measures.push(f);

// ---------- Icons (SF Symbols-like, drawn as SVG) ----------
const ICON = {
  search: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><circle cx="12" cy="12" r="8" fill="none" stroke="${c}" stroke-width="2.6"/><path d="M18 18 L24.5 24.5" stroke="${c}" stroke-width="2.8" stroke-linecap="round"/></svg>`,
  wave: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><g stroke="${c}" stroke-width="2.6" stroke-linecap="round"><path d="M4 11v6"/><path d="M9 7v14"/><path d="M14 4v20"/><path d="M19 8v12"/><path d="M24 12v4"/></g></svg>`,
  laptop: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><rect x="5" y="6" width="18" height="12" rx="2" fill="none" stroke="${c}" stroke-width="2.2"/><path d="M2.5 21.5h23" stroke="${c}" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  play: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><path d="M9 6.5 L22 14 L9 21.5 Z" fill="${c}" stroke="${c}" stroke-width="1.5" stroke-linejoin="round"/></svg>`,
  pause: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><rect x="8" y="6.5" width="4" height="15" rx="1.2" fill="${c}"/><rect x="16" y="6.5" width="4" height="15" rx="1.2" fill="${c}"/></svg>`,
  up: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><path d="M14 22V7 M8 12.5 L14 6.5 L20 12.5" fill="none" stroke="${c}" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  arrow: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><path d="M6.5 14H21 M15.5 8.5 L21 14 L15.5 19.5" fill="none" stroke="${c}" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  chevron: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><path d="M8 11 L14 17 L20 11" fill="none" stroke="${c}" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  skip: (c, dir) => `<svg viewBox="0 0 28 28" width="100%" height="100%"><g transform="${dir < 0 ? '' : 'translate(28 0) scale(-1 1)'}"><path d="M8.3 7.6 A9 9 0 1 0 14 5" fill="none" stroke="${c}" stroke-width="2.1" stroke-linecap="round"/><path d="M14 1.8 L10.4 5 L14 8.2" fill="none" stroke="${c}" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/></g><text x="14" y="17.6" text-anchor="middle" font-family="SF" font-weight="600" font-size="8" fill="${c}">15</text></svg>`,
  copy: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><rect x="9" y="8" width="12" height="15" rx="2.5" fill="none" stroke="${c}" stroke-width="2"/><path d="M7 19V7.5A2.5 2.5 0 0 1 9.5 5H17" fill="none" stroke="${c}" stroke-width="2" stroke-linecap="round"/></svg>`,
  more: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><g fill="${c}"><circle cx="7" cy="14" r="2"/><circle cx="14" cy="14" r="2"/><circle cx="21" cy="14" r="2"/></g></svg>`,
  close: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><path d="M8 8 L20 20 M20 8 L8 20" stroke="${c}" stroke-width="2.4" stroke-linecap="round"/></svg>`,
  speaker: c => `<svg viewBox="0 0 28 28" width="100%" height="100%"><path d="M5 11h4l6-5v16l-6-5H5z" fill="none" stroke="${c}" stroke-width="2" stroke-linejoin="round"/><path d="M19 10.5a5 5 0 0 1 0 7 M22 8a8.5 8.5 0 0 1 0 12" fill="none" stroke="${c}" stroke-width="2" stroke-linecap="round"/></svg>`,
};
// The wavepod mark (WaveShape in Theme.swift): one sound-wave line that settles into a straight page edge.
function wavePath(w, hgt, amp = 1, phase = 0, x0 = 0, y0 = 0) {
  let d = '';
  for (let i = 0; i <= 120; i++) {
    const u = i / 120, env = Math.max(0, 1 - u * 1.25);
    const y = hgt / 2 - Math.sin(u * Math.PI * 7 - phase) * env * hgt * 0.28 * amp;
    d += (i ? 'L' : 'M') + (x0 + w * u).toFixed(2) + ' ' + (y0 + y).toFixed(2);
  }
  return d;
}
function markSVG(parent, w, hgt, stroke, color = 'var(--accent)') {
  const pad = stroke;
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('viewBox', `${-pad} ${-pad} ${w + 2 * pad} ${hgt + 2 * pad}`);
  svg.style.position = 'absolute'; svg.style.overflow = 'visible';
  svg.style.width = (w + 2 * pad) + 'px'; svg.style.height = (hgt + 2 * pad) + 'px';
  const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
  path.setAttribute('fill', 'none'); path.setAttribute('stroke', color); path.setAttribute('stroke-width', stroke);
  path.setAttribute('stroke-linecap', 'round'); path.setAttribute('stroke-linejoin', 'round');
  path.setAttribute('d', wavePath(w, hgt));
  svg.appendChild(path); parent.appendChild(svg);
  return { svg, path, w, hgt, pad };
}

// ---------- Real content from the Disney episode in the user's library ----------
const C = window.CONTENT;
const splitLead = text => { const m = text.replace(/^- /, '').match(/^\*\*(.+?)\*\*\s*(.*)$/); return m ? { lead: m[1], rest: m[2] } : { lead: '', rest: text }; };
const firstSentence = s => { const m = s.match(/^(.+?[.!?])(\s|$)/); return m ? m[1] : s; };
const pointByLead = lead => C.points.find(p => p.text.startsWith('**' + lead));
const leadHTML = (lead, rest) => `<span class="lead">${lead}</span> ${rest}`;

// ---------- Ambient blobs ----------
function blobs(parent, list) {
  return list.map(b => ({ el: h('div', 'blob', parent, { left: b.x - b.r, top: b.y - b.r, width: 2 * b.r, height: 2 * b.r, background: b.c }), ...b }));
}
function blobsAt(arr, t, o = 1) {
  for (const b of arr) put(b.el, { o: o * b.o, x: Math.sin(t * b.sp + b.ph) * b.dx, y: Math.cos(t * b.sp * 0.8 + b.ph) * b.dy, s: 1 + 0.06 * Math.sin(t * 0.7 + b.ph), blur: b.blur || 110 });
}

// =====================================================================================================
// S1 · The problem (0 – 3.45): a line types out, then the camera pushes onto "hour three."
// =====================================================================================================
{
  const sc = scene(0, 3.42);
  const cam = h('div', 'cam', sc.root);
  const line = h('div', 'abs serif nowrap', cam, { left: 0, top: 0, width: W, height: H, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 60, letterSpacing: '-0.01em' });
  const inner = h('div', '', line, { position: 'relative' });
  const TEXT = 'The best part was somewhere in hour three.';
  const words = TEXT.split(' ');
  const chars = [], wordEls = [];
  words.forEach((w, i) => {
    const we = h('span', 'word', inner); wordEls.push(we);
    for (const c of w + (i < words.length - 1 ? ' ' : '')) { const ce = h('span', 'ch', we); ce.textContent = c; chars.push(ce); }
  });
  const caret = h('span', 'caret', inner);
  const tt = typeTimes(TEXT, 0.4, 31, 3);
  const doneAt = tt[tt.length - 1];
  let target = [960, 540];
  onMeasure(() => {
    chars.forEach(c => c.style.display = '');
    const a = rectOf(wordEls[6]), b = rectOf(wordEls[7]);
    target = [(a.left + b.right) / 2, (a.top + a.bottom) / 2 + 4];
  });
  cue('whoosh', 2.0, { len: 1.0, gain: 0.5 });
  sc.update = t => {
    const n = countAt(tt, t);
    chars.forEach((c, i) => { const v = i < n ? '' : 'none'; if (c.style.display !== v) c.style.display = v; });
    caret.style.visibility = t < 2.0 && (t < doneAt + 0.05 || blinkOn(t, doneAt + 0.05)) ? 'visible' : 'hidden';
    const p = P(t, 1.95, 3.0, E.cam);
    const s = lerp(1, 2.45, p) * (1 + 0.025 * P(t, 3.0, 3.42, E.lin));
    const cx = lerp(960, target[0], p), cy = lerp(540, target[1], p), r = lerp(0, -2.4, p);
    cam.style.transform = `translate(960px,540px) rotate(${r}deg) scale(${s}) translate(${-cx}px,${-cy}px)`;
    const sq = P(t, 3.02, 3.2, E.in);
    wordEls.forEach((we, i) => {
      if (i < 6) { const d = 6 - i; put(we, { o: 1 - p * Math.min(0.95, 0.5 + d * 0.09), blur: p * (3 + d * 2.4) }); }
      else put(we, { o: 1 - P(t, 3.18, 3.26, E.lin), sy: lerp(1, 0.04, sq), blur: sq * 1.5 });
    });
  };
}

// =====================================================================================================
// S2 · The chaos (3.2 – 6.65): scrubbing through the real 4:32:56 waveform; late-night questions.
// =====================================================================================================
const QUESTIONS = [
  { text: 'What did they say about Pixar?', time: '11:42 PM' },
  { text: 'Who said that?', time: '11:44 PM' },
  { text: 'Where was that part?', time: '11:51 PM' },
];
function bubble(parent, q, css) {
  const g = h('div', 'abs', parent, css);
  const label = h('div', '', g, { font: '600 19px/1 var(--sans)', color: 'var(--ink)', marginBottom: 10, marginLeft: 6 }, `You <span style="font:500 15px var(--mono);color:var(--muted);margin-left:8px">${q.time}</span>`);
  const b = h('div', 'elev', g, { position: 'relative', borderRadius: 26, height: 72, overflow: 'hidden' });
  const txt = h('div', 'abs nowrap', b, { left: 28, top: 0, lineHeight: '72px', font: '400 34px/72px var(--sans)', color: 'var(--ink)' });
  txt.textContent = q.text;
  const dots = h('div', 'abs', b, { left: 26, top: 31 });
  const ds = [0, 1, 2].map(i => h('span', 'abs', dots, { left: i * 18, top: 0, width: 10, height: 10, borderRadius: 5, background: 'var(--muted)' }));
  return { g, label, b, txt, dots, ds, w: 0 };
}
function bubbleAt(B, t, tDots, tText) {
  const shown = ap(t, tDots, { dur: 0.35, y: 18, blur: 8, s: 0.96 });
  put(B.g, shown);
  const p = P(t, tText, tText + 0.28, E.std);
  B.b.style.width = lerp(100, B.w, p) + 'px';
  put(B.txt, { o: P(t, tText + 0.05, tText + 0.25, E.lin), blur: (1 - P(t, tText, tText + 0.25)) * 6 });
  put(B.dots, { o: 1 - P(t, tText, tText + 0.12, E.lin) });
  B.ds.forEach((d, i) => put(d, { y: -5 * Math.max(0, Math.sin((t - tDots) * 9 - i * 0.9)), o: 0.55 + 0.45 * Math.max(0, Math.sin((t - tDots) * 9 - i * 0.9)) }));
}
{
  const sc = scene(3.2, 6.65);
  const cam = h('div', 'cam', sc.root);
  const layer = h('div', 'full', cam);
  const canvas = h('canvas', 'abs', layer, { left: 0, top: 0, width: W, height: H });
  canvas.width = W; canvas.height = H;
  const ctx = canvas.getContext('2d');
  const tc = h('div', 'abs mono', layer, { left: 0, width: W, top: 300, textAlign: 'center', fontSize: 132, fontWeight: 500, letterSpacing: '-0.03em', color: 'var(--ink)', fontVariantNumeric: 'tabular-nums' });
  const of = h('div', 'abs mono', layer, { left: 0, width: W, top: 458, textAlign: 'center', fontSize: 28, color: 'var(--muted)' }, 'of 4:32:56');
  const lab = h('div', 'abs', layer, { left: 150, top: 840, display: 'flex', alignItems: 'center', gap: '18px' },
    `<img src="assets/artwork.png" style="width:60px;height:60px;border-radius:12px;outline:1px solid rgba(0,0,0,.1);outline-offset:-1px">
     <div><div style="font:600 24px/1.2 var(--sans)">Disney: The Renaissance and the Empire</div><div style="font:400 20px/1.3 var(--sans);color:var(--muted)">Acquired</div></div>`);
  const bubbles = QUESTIONS.map(q => bubble(sc.root, q, { left: 600, top: 0 }));
  onMeasure(() => bubbles.forEach(B => { B.w = B.txt.scrollWidth + 56; }));
  const env = ENVELOPE.values, rate = ENVELOPE.rate;
  const moves = [[3.78, 4.08, 7391], [4.26, 4.56, 2825], [4.74, 5.04, 14282], [5.22, 5.52, 9330], [5.7, 6.0, 6120], [6.18, 6.48, 11000]];
  moves.forEach(m => cue('scrub', m[0], { len: m[1] - m[0] }));
  const pos = t => { let p = 4360; for (const [a, b, to] of moves) { if (t >= b) p = to; else if (t >= a) { p = lerp(p, to, E.inOut((t - a) / (b - a))); break; } else break; } return p; };
  const tDots = [4.5, 4.98, 5.44], tText = [4.76, 5.22, 5.68];
  tDots.forEach(x => cue('pop', x, { pitch: 1 }));
  const pitch = 9, bw = 5, spb = 1.5, cyW = 690, maxH = 330;
  function bar(sec) { let m = 0, n = 0; for (let s = sec; s < sec + spb; s += 1 / rate) { const i = Math.floor(s * rate); if (i >= 0 && i < env.length) { m += env[i] / 255; n++; } } return n ? Math.pow(m / n, 1.5) * 1.25 : -1; }
  sc.update = t => {
    const p0 = P(t, 3.32, 3.95, E.cam);
    const s = lerp(1.22, 1, p0) * (1 + 0.05 * P(t, 3.95, 6.6, E.inOut));
    const cx = 960, cy = lerp(cyW, 560, p0), r = lerp(0, -1.2, P(t, 3.9, 6.6, E.inOut));
    cam.style.transform = `translate(960px,540px) rotate(${r}deg) scale(${s}) translate(${-cx}px,${-cy}px)`;
    const now = pos(t), vel = (pos(t + 1 / 120) - pos(t - 1 / 120)) * 60;
    const half = lerp(330, 1100, P(t, 3.2, 3.7, E.out)), amp = P(t, 3.24, 3.8, E.out);
    ctx.clearRect(0, 0, W, H);
    const pxPerFrame = Math.abs(vel) / 60 / spb * pitch;
    const N = Math.min(10, 1 + Math.floor(pxPerFrame / 6));
    for (let k = 0; k < N; k++) {
      const off = N > 1 ? (k / (N - 1) - 0.5) * Math.min(pxPerFrame, 160) * Math.sign(vel) : 0;
      ctx.globalAlpha = 1 / N * (N > 1 ? 1.25 : 1);
      for (let x = 960 % pitch - pitch; x < W + pitch; x += pitch) {
        if (Math.abs(x - 960) > half) continue;
        const sec = now + (x - 960) / pitch * spb;
        const v = bar(Math.floor(sec / spb) * spb);
        if (v < 0) continue;
        const bh = Math.max(4, Math.min(1, v) * maxH * amp);
        ctx.fillStyle = x < 960 ? 'rgba(28,27,25,0.88)' : 'rgba(28,27,25,0.2)';
        ctx.beginPath(); ctx.roundRect(x + off, cyW - bh / 2, bw, bh, 2.5); ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
    const ph = P(t, 3.55, 3.85, E.out);
    if (ph > 0) {
      ctx.fillStyle = '#0F5E63'; ctx.globalAlpha = ph;
      ctx.beginPath(); ctx.roundRect(958.5, cyW - 190 * ph, 3, 380 * ph, 1.5); ctx.fill();
      ctx.beginPath(); ctx.arc(960, cyW - 190 * ph, 9, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = 1;
    }
    tc.textContent = fmt(now).padStart(7, ' ');
    put(tc, { ...ap(t, 3.6, { dur: 0.45, y: 20, blur: 14 }), blur: lerp(14, 0, P(t, 3.6, 4.05, E.out)) + Math.min(5, Math.abs(vel) / 9000) });
    put(of, ap(t, 3.72, { dur: 0.45, y: 12, blur: 8 }));
    put(lab, ap(t, 3.85, { dur: 0.5, y: 14, blur: 8 }));
    const dof = P(t, 4.45, 4.95, E.inOut);
    put(layer, { o: lerp(1, 0.42, dof) * (1 - P(t, 6.32, 6.55, E.in)), blur: dof * 7 + P(t, 6.32, 6.55, E.in) * 8 });
    bubbles.forEach((B, i) => {
      bubbleAt(B, t, tDots[i], tText[i]);
      if (t > 6.32) put(B.g, { o: 1 - P(t, 6.32, 6.52, E.in), y: -10 * P(t, 6.32, 6.52), blur: 8 * P(t, 6.32, 6.52), s: 1 - 0.03 * P(t, 6.32, 6.52) });
    });
  };
  // Smooth the stack moving up as each bubble arrives: evaluate the slot with an eased count instead of a step.
  const base = sc.update;
  sc.update = t => {
    base(t);
    const eased = tDots.reduce((a, x) => a + P(t, x, x + 0.4, E.std), 0);
    bubbles.forEach((B, i) => { B.g.style.top = (540 - (Math.max(1, eased) * 132) / 2 + i * 132 - 50) + 'px'; });
  };
}

// =====================================================================================================
// S3 · The turn (6.4 – 8.5): "What if you could read it?" followed word by word, then cleared.
// =====================================================================================================
{
  const sc = scene(6.4, 8.46);
  const line = h('div', 'abs serif nowrap', sc.root, { left: 0, top: 0, width: W, height: H, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 66, letterSpacing: '-0.01em' });
  const inner = h('div', '', line, { position: 'relative' });
  const hl = h('div', 'abs', inner, { background: 'var(--word)', borderRadius: 10, zIndex: 0 });
  const TEXT = 'What if you could read it?';
  const words = TEXT.split(' ');
  const chars = [], wordEls = [];
  words.forEach((w, i) => {
    const we = h('span', 'word', inner, { position: 'relative', zIndex: 1 }); wordEls.push(we);
    for (const c of w) { const ce = h('span', 'ch', we); ce.textContent = c; chars.push(ce); }
    if (i < words.length - 1) { const sp = h('span', 'ch', inner, { position: 'relative', zIndex: 1 }); sp.textContent = ' '; chars.push(sp); }
  });
  const caret = h('span', 'caret', inner, { position: 'relative', zIndex: 1 });
  const tt = typeTimes(TEXT, 6.56, 34, 9);
  const doneAt = tt[tt.length - 1];
  const kStart = 7.42, kStep = 0.095;
  words.forEach((_, i) => cue('tick', kStart + i * kStep, { gain: 0.35 }));
  const tSel = kStart + words.length * kStep + 0.02, tDel = tSel + 0.12;
  cue('select', tSel); cue('delete', tDel);
  let rects = [];
  onMeasure(() => {
    chars.forEach(c => c.style.display = '');
    const ib = rectOf(inner);
    rects = wordEls.map(we => { const r = rectOf(we); return [r.left - ib.left, r.top - ib.top, r.width, r.height]; });
  });
  sc.update = t => {
    const n = t >= tDel ? 0 : countAt(tt, t);
    chars.forEach((c, i) => { const v = i < n ? '' : 'none'; if (c.style.display !== v) c.style.display = v; });
    caret.style.visibility = t >= tDel || t < doneAt + 0.05 || (t < kStart && blinkOn(t, doneAt + 0.05)) ? 'visible' : 'hidden';
    if (t >= kStart && t < tDel) {
      const pad = 8;
      let x, y, w, hh;
      if (t < tSel) {
        const k = Math.min(words.length - 1, Math.floor((t - kStart) / kStep));
        const pk = P(t, kStart + k * kStep, kStart + k * kStep + 0.07, E.std);
        const a = rects[Math.max(0, k - 1)], b = rects[k];
        const q = k === 0 ? 1 : pk;
        x = lerp(a[0], b[0], q); w = lerp(a[2], b[2], q); y = b[1]; hh = b[3];
      } else {
        const ps = P(t, tSel, tSel + 0.08, E.std), last = rects[rects.length - 1], b = rects[rects.length - 1];
        x = lerp(b[0], rects[0][0], ps); w = lerp(b[2], last[0] + last[2] - rects[0][0], ps); y = b[1]; hh = b[3];
      }
      Object.assign(hl.style, { left: (x - pad) + 'px', top: (y + 4) + 'px', width: (w + pad * 2) + 'px', height: (hh - 2) + 'px' });
      put(hl, { o: k0(t) });
    } else put(hl, { o: 0 });
    function k0(t) { return P(t, kStart, kStart + 0.06, E.lin); }
  };
}

// =====================================================================================================
// S4 · Meet Wavepod (8.35 – 10.4): the caret becomes the wave mark; it rings out and settles flat.
// =====================================================================================================
const BLOBS = [
  { x: 1500, y: 180, r: 420, c: 'rgba(191,220,215,.85)', o: 1, sp: 0.35, ph: 0, dx: 60, dy: 40 },
  { x: 380, y: 900, r: 460, c: 'rgba(246,194,122,.42)', o: 1, sp: 0.3, ph: 2, dx: 70, dy: 35 },
  { x: 960, y: 520, r: 360, c: 'rgba(227,238,236,.9)', o: 1, sp: 0.25, ph: 4, dx: 40, dy: 30 },
];
const MARK = { w: 420, h: 250, stroke: 30, cx: 960, cy: 410 };
{
  const sc = scene(8.36, 10.4);
  const bl = blobs(sc.root, BLOBS);
  const cam = h('div', 'cam', sc.root);
  const caret = h('div', 'abs', cam, { left: 958, top: 507, width: 4, height: 66, background: 'var(--ink)', borderRadius: 2 });
  const holder = h('div', 'abs', cam, { left: MARK.cx - MARK.w / 2 - MARK.stroke, top: MARK.cy - MARK.h / 2 - MARK.stroke });
  const m = markSVG(holder, MARK.w, MARK.h, MARK.stroke);
  const rings = [8.5, 8.74, 8.98].map(() => h('div', 'abs', cam, { borderRadius: '50%', border: '2px solid var(--accent)' }));
  const title = h('div', 'abs serif nowrap', cam, { left: 0, width: W, top: 590, textAlign: 'center', fontSize: 132, fontWeight: 600, letterSpacing: '-0.02em' });
  const meet = h('span', '', title, { display: 'inline-block' }, 'Meet');
  h('span', '', title, null, ' ');
  const name = h('span', '', title, { display: 'inline-block', color: 'var(--accent)' }, 'Wavepod.');
  cue('riser', 7.1, { len: 1.32 }); cue('boom', 8.42); cue('chime', 8.5); cue('ring', 8.5); cue('ring', 8.74); cue('ring', 8.98);
  cue('whoosh', 8.95, { len: 0.5, gain: 0.35 });
  sc.update = t => {
    blobsAt(bl, t, P(t, 8.4, 9.2, E.inOut));
    const camS = 1 + 0.04 * P(t, 8.4, 10.4, E.inOut);
    cam.style.transform = `translate(960px,540px) scale(${camS}) translate(-960px,-540px)`;
    // The caret tips over into the start of the line.
    const pc = P(t, 8.36, 8.5, E.std);
    put(caret, { o: 1 - P(t, 8.48, 8.52, E.lin), r: 90 * pc, sy: lerp(1, 0.4, pc), x: lerp(0, -MARK.w / 2, pc), y: lerp(0, MARK.cy - 540, pc) });
    const draw = P(t, 8.47, 9.05, E.out);
    const settle = P(t, 8.47, 9.7, E.out);
    const amp = t < 8.85 ? lerp(0.25, 1.4, P(t, 8.47, 8.85, E.out)) : 1 + 0.4 * Math.exp(-(t - 8.85) * 4.2) * Math.cos((t - 8.85) * 13);
    m.path.setAttribute('d', wavePath(MARK.w, MARK.h, amp, (1 - settle) * Math.PI * 3));
    const L = m.path.getTotalLength();
    m.path.style.strokeDasharray = `${L} ${L}`;
    m.path.style.strokeDashoffset = L * (1 - draw);
    put(holder, { o: t < 8.47 ? 0 : 1 });
    rings.forEach((rg, i) => {
      const t0 = [8.5, 8.74, 8.98][i], p = P(t, t0, t0 + 1.5, E.out), rad = lerp(70, 620, p);
      Object.assign(rg.style, { left: (MARK.cx - rad) + 'px', top: (MARK.cy - rad) + 'px', width: 2 * rad + 'px', height: 2 * rad + 'px' });
      put(rg, { o: t < t0 ? 0 : 0.35 * (1 - p) });
    });
    put(meet, ap(t, 8.95, { dur: 0.6, y: 22, blur: 18, s: 0.97 }, 10.12, { dur: 0.2, blur: 10, y: -10 }));
    put(name, ap(t, 9.12, { dur: 0.6, dx: -26, y: 0, blur: 18 }, 10.15, { dur: 0.2, blur: 10, y: -10 }));
  };
}

// =====================================================================================================
// S5 · Find and transcribe (10.25 – 13.75): the mark opens into the search field; ⌘K, type, Transcribe.
// =====================================================================================================
const cursorTrack = [], cursorWindows = [], clicks = [];
let searchTarget = null, transcribeBtn = null;
{
  const sc = scene(10.25, 13.78);
  const bl = blobs(sc.root, BLOBS);
  const stream = h('div', 'abs serif', sc.root, { left: 360, width: 1200, top: 0, fontSize: 30, lineHeight: 1.6, color: 'var(--muted)' });
  C.stream.slice(0, 18).forEach(s => h('div', 'nowrap', stream, { overflow: 'hidden', textOverflow: 'ellipsis' }).textContent = s);
  const PILL = { cx: 960, cy: 470, w: 1180, h: 96 };
  const pill = h('div', 'abs elev pill', sc.root, { left: 0, top: PILL.cy - PILL.h / 2, height: PILL.h });
  const mag = h('div', 'abs', sc.root, { width: 36, height: 36 }, ICON.search('#0F5E63'));
  const markHolder = h('div', 'abs', sc.root, { left: MARK.cx - MARK.w / 2 - MARK.stroke, top: MARK.cy - MARK.h / 2 - MARK.stroke, width: MARK.w + 2 * MARK.stroke, height: MARK.h + 2 * MARK.stroke, transformOrigin: '50% 50%' });
  markSVG(markHolder, MARK.w, MARK.h, MARK.stroke);
  const ph = h('div', 'abs nowrap', sc.root, { left: PILL.cx - PILL.w / 2 + 94, top: PILL.cy - 20, font: '400 31px/40px var(--sans)', color: 'var(--muted)' }, 'Search or paste a podcast, Spotify or YouTube link');
  const typed = h('div', 'abs nowrap', sc.root, { left: PILL.cx - PILL.w / 2 + 94, top: PILL.cy - 20, font: '400 31px/40px var(--sans)', color: 'var(--ink)' });
  const tText = h('span', '', typed); const tCaret = h('span', 'caret', typed, { width: '2.5px', background: 'var(--accent)' });
  const key = h('div', 'abs keycap', sc.root, { left: PILL.cx + PILL.w / 2 - 102, top: PILL.cy - 25 }, '⌘K');
  const focus = h('div', 'abs pill', sc.root, { left: PILL.cx - PILL.w / 2 - 6, top: PILL.cy - PILL.h / 2 - 6, width: PILL.w + 12, height: PILL.h + 12, boxShadow: '0 0 0 4px rgba(15,94,99,.22)' });
  const res = h('div', 'abs elev', sc.root, { left: PILL.cx - PILL.w / 2, top: PILL.cy + PILL.h / 2 + 18, width: PILL.w, height: 152, borderRadius: 28 });
  res.innerHTML = `
    <img src="assets/artwork.png" style="position:absolute;left:24px;top:24px;width:104px;height:104px;border-radius:16px;outline:1px solid rgba(0,0,0,.1);outline-offset:-1px">
    <div style="position:absolute;left:152px;top:36px;font:600 34px/1.15 var(--serif);white-space:nowrap">Disney: The Renaissance and the Empire</div>
    <div style="position:absolute;left:152px;top:86px;font:400 23px/1.2 var(--sans);color:var(--muted)">Acquired · 10 Aug 2026 · 4:32:56</div>`;
  const btn = h('div', 'abs', res, { right: 28, top: 45, height: 62, padding: '0 28px 0 22px', borderRadius: 16, background: 'var(--accent)', color: '#fff', display: 'flex', alignItems: 'center', gap: '12px', font: '600 25px/1 var(--sans)' }, `<span style="width:30px;height:30px;display:inline-block">${ICON.wave('#fff')}</span>Transcribe`);
  transcribeBtn = btn;
  const eyebrow = h('div', 'abs eyebrow', sc.root, { left: PILL.cx - PILL.w / 2 + 4, top: 368, fontSize: 21 }, 'In progress');
  const card = h('div', 'abs elev', sc.root, { left: PILL.cx - PILL.w / 2, top: 410, width: PILL.w, height: 206, borderRadius: 30 });
  const pct = h('div', 'abs', card, { left: 40, top: 0, height: 206, width: 140, display: 'flex', alignItems: 'center', font: '500 38px/1 var(--sans)', fontVariantNumeric: 'tabular-nums' });
  h('div', 'abs nowrap', card, { left: 196, top: 40, font: '600 32px/1.2 var(--sans)' }, 'Disney: The Renaissance and the Empire');
  const statusBox = h('div', 'abs', card, { left: 196, top: 88, height: 34, width: 600, font: '400 26px/34px var(--sans)', color: 'var(--muted)' });
  const status = makeRoll(statusBox, [
    { t: 12.52, text: 'Downloading' }, { t: 12.74, text: 'Transcribing window 2' }, { t: 12.94, text: 'Transcribing window 6' },
    { t: 13.14, text: 'Identifying speakers, window 3' }, { t: 13.34, text: 'Summarizing' }]);
  status.items.forEach((it, i) => i && cue('tick', it.t, { gain: 0.5 }));
  const chip = h('div', 'abs', card, { right: 36, top: 40, height: 44, padding: '0 18px 0 14px', borderRadius: 22, background: 'var(--accentSoft)', color: 'var(--accent)', display: 'flex', alignItems: 'center', gap: '10px', font: '600 21px/1 var(--sans)' }, `<span style="width:26px;height:26px;display:inline-block">${ICON.laptop('#0F5E63')}</span>On this Mac`);
  const track = h('div', 'abs', card, { left: 196, top: 148, width: 940, height: 12, borderRadius: 6, background: '#ECE8E1', overflow: 'hidden' });
  const fill = h('div', 'abs', track, { left: 0, top: 0, height: 12, borderRadius: 6, background: 'var(--accent)' });
  void chip;
  cue('key2', 11.0); cue('whoosh', 10.3, { len: 0.5, gain: 0.3 });
  const tt = typeTimes('Acquired Disney', 11.14, 28, 21);
  const doneAt = tt[tt.length - 1];
  cue('pop', 11.72, { pitch: 0.8 });
  // Cursor: from the lower right to Transcribe, click.
  cursorWindows.push([11.74, 12.5]);
  cursorTrack.push({ t: 11.74, at: () => [1560, 930] }, { t: 11.78, at: () => centerOf(btn), move: 0.36 });
  clicks.push(12.15);
  sc.update = t => {
    blobsAt(bl, t, 1 - 0.55 * P(t, 10.3, 11.2, E.inOut));
    // The mark slides to the field's leading edge and shrinks as the field opens.
    const pm = P(t, 10.27, 10.7, E.std);
    const iconX = PILL.cx - PILL.w / 2 + 56, iconY = PILL.cy;
    put(markHolder, { o: 1 - P(t, 10.56, 10.72, E.lin), x: lerp(0, iconX - MARK.cx, pm), y: lerp(0, iconY - MARK.cy, pm), s: lerp(1, 0.13, pm), blur: P(t, 10.56, 10.72) * 4 });
    const pi = P(t, 10.58, 10.86, E.std);
    Object.assign(mag.style, { left: (iconX - 18) + 'px', top: (iconY - 18) + 'px' });
    put(mag, { o: pi * (1 - P(t, 12.3, 12.5, E.in)), s: lerp(0.25, 1, pi), blur: (1 - pi) * 4, y: -16 * P(t, 12.3, 12.5) });
    const pw = P(t, 10.32, 10.78, E.std);
    const w = lerp(PILL.h, PILL.w, pw);
    pill.style.left = (PILL.cx - w / 2) + 'px'; pill.style.width = w + 'px';
    const out = P(t, 12.3, 12.52, E.in);
    put(pill, { o: P(t, 10.3, 10.4, E.lin) * (1 - out), y: -16 * out, blur: 8 * out });
    put(ph, { ...ap(t, 10.66, { dur: 0.4, y: 0, dx: -12, blur: 8 }), o: ap(t, 10.66, { dur: 0.4 }).o * (t < 11.05 ? 1 : 0) });
    const kp = t >= 11.0 && t < 11.12;
    put(key, { ...ap(t, 10.74, { dur: 0.4, y: 0, blur: 8, s: 0.9 }, 12.3, { dur: 0.2 }), y: kp ? 3 : 0 });
    key.style.boxShadow = kp ? '0 0 0 var(--keyEdge)' : '0 3px 0 var(--keyEdge)';
    put(focus, { o: P(t, 11.02, 11.18, E.lin) * (1 - out), y: -16 * out });
    const n = countAt(tt, t);
    tText.textContent = 'Acquired Disney'.slice(0, n);
    put(typed, { o: t >= 11.04 ? 1 - out : 0, y: -16 * out, blur: 8 * out });
    tCaret.style.visibility = t < doneAt + 0.05 || blinkOn(t, doneAt + 0.05) ? 'visible' : 'hidden';
    // The result, the press, then the row becomes the progress card.
    const pressed = t >= 12.15 && t < 12.27;
    put(btn, { s: pressed ? 0.96 : 1 });
    put(res, ap(t, 11.72, { dur: 0.42, y: 18, blur: 10, s: 0.98 }, 12.32, { dur: 0.22, y: -40, blur: 10, s: 0.97 }));
    const cin = ap(t, 12.36, { dur: 0.5, y: 36, blur: 12, s: 0.98 }, 13.34, { dur: 0.2, y: -12, blur: 10, s: 1.04 });
    put(card, cin);
    put(eyebrow, ap(t, 12.42, { dur: 0.45, y: 12, blur: 6 }, 13.32, { dur: 0.18 }));
    const pr = P(t, 12.52, 13.42, E.inOut);
    fill.style.width = (940 * pr) + 'px';
    pct.textContent = Math.round(pr * 100) + ' %';
    rollAt(status, t);
    // Transcript text streams past behind the card while it runs.
    const sp = P(t, 12.4, 13.78, E.lin);
    put(stream, { o: 0.16 * P(t, 12.4, 12.7, E.lin) * (1 - P(t, 13.4, 13.7, E.lin)), y: lerp(560, -260, sp), blur: 2.2 });
  };
}

// =====================================================================================================
// S6–S7 · The episode (13.35 – 21.6): summary, click a point, the transcript plays; then ask the episode.
// =====================================================================================================
let playLabelCenter = [960, 540];
{
  const sc = scene(13.35, 21.6);
  const world = h('div', 'cam', sc.root);
  const pane = h('div', 'abs elev', world, { left: 150, top: 90, width: 850, height: 880, borderRadius: 30, overflow: 'hidden' });
  pane.innerHTML = `
    <img src="assets/artwork.png" style="position:absolute;left:48px;top:48px;width:128px;height:128px;border-radius:18px;outline:1px solid rgba(0,0,0,.1);outline-offset:-1px">
    <div style="position:absolute;left:204px;top:44px;font:500 24px/1 var(--sans);color:var(--accent);display:flex;align-items:center;gap:6px">Acquired <span style="width:20px;height:20px;display:inline-block">${ICON.chevron('#0F5E63')}</span></div>
    <div style="position:absolute;left:204px;top:80px;width:600px;font:600 44px/1.12 var(--serif);letter-spacing:-0.01em">Disney: The Renaissance and the Empire</div>
    <div style="position:absolute;left:204px;top:190px;font:400 22px/1 var(--sans);color:var(--muted)">10 Aug 2026 · 4:32:56</div>
    <div style="position:absolute;right:48px;top:168px;height:60px;padding:0 28px 0 22px;border-radius:15px;background:var(--accent);color:#fff;display:flex;align-items:center;gap:10px;font:600 24px/1 var(--sans)"><span style="width:24px;height:24px;display:inline-block">${ICON.play('#fff')}</span>Play</div>
    <div style="position:absolute;left:0;right:0;top:372px;height:1px;background:var(--rule)"></div>`;
  const ask = h('div', 'abs pill', pane, { left: 48, right: 48, top: 252, height: 80, background: 'var(--sunken)' });
  h('div', 'abs', ask, { left: 26, top: 22, width: 36, height: 36 }, ICON.search('#0F5E63'));
  const askPh = h('div', 'abs nowrap', ask, { left: 78, top: 0, font: '400 26px/80px var(--sans)', color: 'var(--muted)' }, 'Ask or search this episode');
  const askTyped = h('div', 'abs nowrap', ask, { left: 78, top: 0, font: '400 26px/80px var(--sans)', color: 'var(--ink)' });
  const askText = h('span', '', askTyped); const askCaret = h('span', 'caret', askTyped, { width: '2.5px', background: 'var(--accent)' });
  const send = h('div', 'abs', ask, { right: 14, top: 13, width: 54, height: 54, borderRadius: 27, background: '#DDD7CC', padding: '13px' }, ICON.up('#fff'));
  const askFocus = h('div', 'abs pill', pane, { left: 42, right: 42, top: 246, height: 92, boxShadow: '0 0 0 4px rgba(15,94,99,.22)' });

  // Summary.
  const sum = h('div', 'abs', pane, { left: 48, top: 414, width: 754 });
  const e1 = h('div', 'eyebrow', sum, null, 'Summary');
  const e2 = h('div', 'eyebrow', sum, { marginTop: 34 }, 'Main discussion');
  const leads = ['Streaming transition', '1984 crisis', 'Broken profit engine'];
  const rows = leads.map((ld, i) => {
    const p = pointByLead(ld), { lead, rest } = splitLead(p.text);
    const row = h('div', '', sum, { position: 'relative', marginTop: i ? 6 : 24, marginLeft: -14, marginRight: -14, padding: '12px 14px', borderRadius: 14, display: 'grid', gridTemplateColumns: '24px 1fr 118px', alignItems: 'start' });
    const bg = h('div', 'abs', row, { inset: 0, borderRadius: 14, background: 'var(--selection)' });
    h('div', '', row, { position: 'relative', width: 9, height: 9, borderRadius: 5, background: 'var(--muted)', marginTop: 16 });
    h('div', 'serif', row, { position: 'relative', fontSize: 25, lineHeight: 1.5 }, leadHTML(lead, firstSentence(rest)));
    const lab = h('div', '', row, { position: 'relative', justifySelf: 'end', marginTop: 8, display: 'flex', alignItems: 'center', gap: '8px', font: '600 21px/1 var(--sans)', color: 'var(--accent)' }, `<span style="width:20px;height:20px;display:inline-block">${ICON.play('#0F5E63')}</span>${fmt(p.start)}`);
    return { row, bg, lab, start: p.start };
  });

  // Answer.
  const ans = h('div', 'abs', pane, { left: 48, top: 414, width: 754 });
  const a1 = h('div', 'eyebrow', ans, null, 'Answers');
  const qh = h('div', 'serif', ans, { marginTop: 22, font: '600 36px/1.25 var(--serif)' }, C.question);
  const statusBox = h('div', '', ans, { position: 'relative', marginTop: 26, height: 34, display: 'flex', alignItems: 'center', gap: '14px', font: '400 23px/34px var(--sans)', color: 'var(--muted)' });
  const spin = h('div', '', statusBox, { width: 26, height: 26, borderRadius: 13, border: '3px solid var(--rule)', borderTopColor: 'var(--accent)' });
  const stBox = h('div', '', statusBox, { position: 'relative', height: 34, width: 500 });
  const st = makeRoll(stBox, [{ t: 19.18, text: 'Preparing transcript…' }, { t: 19.5, text: 'Reading transcript 2 of 6…' }, { t: 19.8, text: 'Reading transcript 5 of 6…' }]);
  st.items.forEach((it, i) => i && cue('tick', it.t, { gain: 0.45 }));
  const sec = C.answer[0];
  const a2 = h('div', 'eyebrow', ans, { position: 'absolute', top: 152 }, sec.title);
  const aRows = sec.points.slice(0, 3).map((p, i) => {
    const { lead, rest } = splitLead(p.text);
    const row = h('div', '', ans, { position: 'absolute', left: -14, right: -14, padding: '12px 14px', borderRadius: 14, display: 'grid', gridTemplateColumns: '24px 1fr 128px', alignItems: 'start' });
    const bg = h('div', 'abs', row, { inset: 0, borderRadius: 14, background: 'var(--selection)' });
    h('div', '', row, { position: 'relative', width: 9, height: 9, borderRadius: 5, background: 'var(--muted)', marginTop: 16 });
    h('div', 'serif', row, { position: 'relative', fontSize: 25, lineHeight: 1.5 }, leadHTML(lead, firstSentence(rest)));
    const lab = h('div', '', row, { position: 'relative', justifySelf: 'end', marginTop: 8, display: 'flex', alignItems: 'center', gap: '8px', font: '600 21px/1 var(--sans)', color: 'var(--accent)' }, `<span style="width:20px;height:20px;display:inline-block">${ICON.play('#0F5E63')}</span>${fmt(p.citation.start)}`);
    return { row, bg, lab, quote: p.citation.quote, start: p.citation.start };
  });
  const tip = h('div', 'abs', world, { width: 640, padding: '14px 18px', borderRadius: 12, background: '#fff', boxShadow: '0 1px 2px rgba(0,0,0,.1), 0 10px 30px rgba(0,0,0,.14)', font: '400 21px/1.4 var(--sans)', color: 'var(--ink)' });
  const q0 = aRows[0].quote.split(' ').slice(0, 14).join(' ');
  tip.innerHTML = `“${q0}…” · Play from ${fmt(aRows[0].start)}`;

  // Transcript pane.
  const tp = h('div', 'abs elev', world, { left: 1030, top: 90, width: 750, height: 880, borderRadius: 30, overflow: 'hidden' });
  tp.innerHTML = `
    <div style="position:absolute;left:36px;top:30px;padding:5px;border-radius:14px;background:var(--sunken);display:flex;font:500 24px/1 var(--sans)">
      <div style="padding:12px 22px;border-radius:10px;background:var(--accent);color:#fff">Transcript</div><div style="padding:12px 22px;color:var(--ink)">About</div></div>
    <div style="position:absolute;right:36px;top:40px;display:flex;gap:26px">${['copy', 'more', 'close'].map(k => `<span style="width:30px;height:30px;display:inline-block">${ICON[k]('#1C1B19')}</span>`).join('')}</div>
    <div style="position:absolute;left:0;right:0;top:112px;height:1px;background:var(--rule)"></div>`;
  const tbody = h('div', 'abs', tp, { left: 34, top: 140, width: 682 });
  const segWords = C.segments.flatMap(s => s.words.map(w => ({ text: w[0], start: w[1], speaker: s.speaker })));
  const from = (word, at) => segWords.findIndex(w => w.text === word && Math.abs(w.start - at) < 0.05);
  const span = (a, b) => segWords.slice(a, b + 1);
  const i1 = from('In', 500.96), i1e = segWords.findIndex((w, i) => i > i1 && w.text === 'TV.');
  const i2 = i1e + 1, i2e = segWords.findIndex((w, i) => i > i2 && w.text === 'broken.');
  const i3 = from('A', 518.48), i3e = segWords.findIndex((w, i) => i > i3 && w.text === 'company.');
  const SPK = { S1: { name: 'Ben Gilbert', c: 'var(--sp0)', note: 'suggested · 80%' }, S3: { name: 'Speaker 3', c: 'var(--sp2)', note: '' } };
  const paras = [[i1, i1e], [i2, i2e], [i3, i3e]].map(([a, b]) => {
    const ws = span(a, b), spk = SPK[ws[0].speaker];
    const para = h('div', '', tbody, { position: 'relative', padding: '14px 14px 16px', borderRadius: 16, marginBottom: 10 });
    const bg = h('div', 'abs', para, { inset: 0, borderRadius: 16, background: 'var(--highlight)' });
    h('div', '', para, { position: 'relative', display: 'flex', alignItems: 'center', gap: '12px', marginBottom: 10 },
      `<span class="tpill">${fmt(ws[0].start)}</span><span class="dot" style="background:${spk.c}"></span><span style="font:600 22px/1 var(--sans);color:${spk.c}">${spk.name}</span><span style="font:400 20px/1 var(--sans);color:var(--muted)">${spk.note}</span>`);
    const text = h('div', 'serif', para, { position: 'relative', fontSize: 25, lineHeight: 1.5 });
    const hl = h('div', 'abs', text, { background: 'var(--word)', borderRadius: 6 });
    const wEls = ws.map((w, k) => { const e = h('span', '', text, { position: 'relative' }); e.textContent = w.text + (k < ws.length - 1 ? ' ' : ''); return { e, start: w.start }; });
    return { para, bg, text, hl, wEls };
  });
  const playStart = 15.62, rtAt = t => 500.96 + Math.max(0, t - playStart);

  // Player bar.
  const bar = h('div', 'abs elev', world, { left: 150, top: 986, width: 1630, height: 124, borderRadius: 26 });
  bar.innerHTML = `
    <img src="assets/artwork.png" style="position:absolute;left:24px;top:18px;width:64px;height:64px;border-radius:10px">
    <div style="position:absolute;left:106px;top:22px;font:400 19px/1.2 var(--sans);color:var(--muted)">Acquired</div>
    <div style="position:absolute;left:106px;top:48px;font:500 23px/1.2 var(--sans)">Disney: The Renaissance and the Empire</div>
    <div style="position:absolute;left:${815 - 112}px;top:30px;width:40px;height:40px">${ICON.skip('#1C1B19', -1)}</div>
    <div style="position:absolute;left:${815 + 72}px;top:30px;width:40px;height:40px">${ICON.skip('#1C1B19', 1)}</div>
    <div style="position:absolute;right:96px;top:36px;font:500 23px/1 var(--sans)">1×</div>
    <div style="position:absolute;right:30px;top:32px;width:34px;height:34px">${ICON.speaker('#1C1B19')}</div>`;
  const pbtn = h('div', 'abs', bar, { left: 815 - 34, top: 16, width: 68, height: 68, borderRadius: 34, background: 'var(--ink)' });
  const pPlay = h('div', 'abs', pbtn, { left: 18, top: 17, width: 34, height: 34 }, ICON.play('#fff'));
  const pPause = h('div', 'abs', pbtn, { left: 17, top: 17, width: 34, height: 34 }, ICON.pause('#fff'));
  const tL = h('div', 'abs mono', bar, { left: 24, top: 92, font: '500 18px/1 var(--mono)', color: 'var(--muted)' });
  const tR = h('div', 'abs mono', bar, { right: 24, top: 92, font: '500 18px/1 var(--mono)', color: 'var(--muted)' });
  const ptrack = h('div', 'abs', bar, { left: 120, right: 140, top: 98, height: 6, borderRadius: 3, background: '#E9E5DE' });
  const pfill = h('div', 'abs', ptrack, { left: 0, top: 0, height: 6, borderRadius: 3, background: 'var(--accent)' });

  // Camera keys: [start, end, cx, cy, s]. Between keys the camera holds; each key eases from the previous one.
  const keys = [[13.35, 13.35, 575, 470, 1.16], [13.4, 14.9, 575, 520, 1.2], [15.15, 15.95, 965, 560, 1.0], [15.95, 16.8, 965, 548, 1.03],
    [16.78, 17.38, 560, 392, 1.42], [18.88, 19.6, 575, 600, 1.2], [19.6, 21.05, 575, 640, 1.23], [21.05, 21.6, 600, 650, 1.32]];
  const camAt = t => {
    let c = keys[0].slice(2);
    for (const [a, b, ...to] of keys) { if (t >= b) c = to; else if (t >= a) { const p = E.cam((t - a) / (b - a)); c = c.map((v, i) => lerp(v, to[i], p)); break; } else break; }
    return c;
  };
  cue('whoosh', 15.15, { len: 0.8, gain: 0.35 }); cue('whoosh', 16.78, { len: 0.6, gain: 0.3 }); cue('whoosh', 18.88, { len: 0.7, gain: 0.3 });
  cue('pop', 15.3, { pitch: 1.2, gain: 0.5 });
  const qTimes = typeTimes(C.question, 17.48, 38, 33);
  const qDone = qTimes[qTimes.length - 1];
  cue('send', 18.84);
  cue('pop', 20.12, { pitch: 1.0, gain: 0.5 }); cue('pop', 20.22, { pitch: 1.12, gain: 0.4 }); cue('pop', 20.32, { pitch: 1.25, gain: 0.35 });
  cue('tickSoft', 13.72); cue('tickSoft', 13.82); cue('tickSoft', 13.92);

  // Cursor path: the summary point, the Ask field, the send button, the answer's play label.
  cursorWindows.push([14.22, 17.5], [18.5, 21.25]);
  cursorTrack.push(
    { t: 14.22, at: () => [1340, 980] },
    { t: 14.3, at: () => { const r = rectOf(rows[2].row); return [r.left + r.width * 0.55, r.top + r.height * 0.5]; }, move: 0.48 },
    { t: 16.6, at: () => { const r = rectOf(ask); return [r.left + r.width * 0.42, r.top + r.height * 0.55]; }, move: 0.7 },
    { t: 18.5, at: () => { const r = rectOf(ask); return [r.left + r.width * 0.72, r.top + r.height * 1.6]; } },
    { t: 18.52, at: () => centerOf(send), move: 0.26 },
    { t: 18.95, at: () => { const r = rectOf(ask); return [r.left + r.width * 0.9, r.top + r.height * 3.2]; }, move: 0.8 },
    { t: 20.46, at: () => { const r = rectOf(aRows[0].row); return [r.left + r.width * 0.5, r.top + r.height * 0.42]; }, move: 0.42 },
    { t: 20.95, at: () => centerOf(aRows[0].lab), move: 0.17 },
  );
  clicks.push(15.15, 17.36, 18.82, 21.15);

  sc.update = t => {
    const [cx, cy, s] = camAt(t);
    world.style.transform = `translate(960px,540px) scale(${s}) translate(${-cx}px,${-cy}px)`;
    // The pane arrives from the progress card.
    put(pane, ap(t, 13.42, { dur: 0.55, y: 30, blur: 12, s: 0.97 }));
    // Summary, staggered 100 ms.
    const sOut = 18.9;
    put(e1, ap(t, 13.62, { dur: 0.4, y: 12, blur: 6 }, sOut, { dur: 0.2, y: 12 }));
    put(e2, ap(t, 13.66, { dur: 0.4, y: 12, blur: 6 }, sOut + 0.02, { dur: 0.2, y: 12 }));
    rows.forEach((r, i) => {
      put(r.row, ap(t, 13.72 + i * 0.1, { dur: 0.45, y: 14, blur: 6 }, sOut + 0.04 + i * 0.03, { dur: 0.2, y: 14 }));
      const hov = i === 2 ? P(t, 14.78, 14.93, E.lin) * (1 - P(t, 15.6, 15.9, E.lin)) : 0;
      put(r.bg, { o: hov }); put(r.lab, { o: hov });
      put(r.row.children[2], { s: i === 2 && t >= 15.15 && t < 15.27 ? 0.97 : 1 });
    });
    // Ask field: focus, type, send.
    put(askFocus, { o: P(t, 17.36, 17.5, E.lin) * (1 - P(t, 18.9, 19.1, E.lin)) });
    const n = t < 18.9 ? countAt(qTimes, t) : 0;
    askText.textContent = C.question.slice(0, n);
    put(askPh, { o: t < 17.4 || t >= 19.0 ? (t >= 19 ? P(t, 19.0, 19.2, E.lin) : 1) : 0 });
    put(askTyped, { o: t >= 17.4 && t < 18.92 ? 1 : 0 });
    askCaret.style.visibility = t < qDone + 0.05 || blinkOn(t, qDone + 0.05) ? 'visible' : 'hidden';
    send.style.background = n > 0 ? 'var(--accent)' : '#DDD7CC';
    put(send, { s: t >= 18.82 && t < 18.94 ? 0.92 : 1 });
    // Answer.
    put(ans, { o: t >= 18.95 ? 1 : 0 });
    put(a1, ap(t, 18.98, { dur: 0.4, y: 12, blur: 6 }));
    put(qh, ap(t, 18.98, { dur: 0.55, y: -70, blur: 10, s: 0.92 }));
    put(statusBox, ap(t, 19.14, { dur: 0.35, y: 10, blur: 6 }, 20.04, { dur: 0.2, y: -10 }));
    spin.style.transform = `rotate(${(t * 540) % 360}deg)`;
    rollAt(st, t);
    put(a2, ap(t, 20.06, { dur: 0.4, y: 12, blur: 6 }));
    let y = 196;
    aRows.forEach((r, i) => {
      r.row.style.top = y + 'px'; y += r.row.offsetHeight + 6;
      put(r.row, ap(t, 20.12 + i * 0.1, { dur: 0.45, y: 14, blur: 6 }));
      const hov = i === 0 ? P(t, 20.9, 21.05, E.lin) : 0;
      put(r.bg, { o: hov }); put(r.lab, { o: hov, s: i === 0 && t >= 21.15 && t < 21.27 ? 0.94 : 1 });
    });
    const tr = rectOf(aRows[0].row), wr = rectOf(world), sc2 = s;
    tip.style.left = ((tr.left - wr.left) / sc2 + 120) + 'px'; tip.style.top = ((tr.bottom - wr.top) / sc2 - 6) + 'px';
    put(tip, ap(t, 21.05, { dur: 0.2, y: 6, blur: 0 }));
    playLabelCenter = centerOf(aRows[0].lab);
    // Transcript pane and player.
    put(tp, ap(t, 15.22, { dur: 0.6, dx: 80, y: 0, blur: 12 }, 16.9, { dur: 0.3, dx: 40, y: 0, blur: 8 }));
    const rt = rtAt(t);
    paras.forEach((pa, k) => {
      put(pa.bg, { o: k === 0 ? P(t, 15.45, 15.65, E.lin) : 0 });
      if (k === 0 && t >= playStart) {
        let wi = 0; pa.wEls.forEach((w, j) => { if (w.start <= rt) wi = j; });
        const cur = pa.wEls[wi].e, prev = pa.wEls[Math.max(0, wi - 1)].e;
        const q = P(rt, pa.wEls[wi].start, pa.wEls[wi].start + 0.09, E.std);
        const A = [prev.offsetLeft, prev.offsetTop, prev.offsetWidth, prev.offsetHeight], B = [cur.offsetLeft, cur.offsetTop, cur.offsetWidth, cur.offsetHeight];
        const same = A[1] === B[1];
        const x = same ? lerp(A[0], B[0], q) : B[0], w = same ? lerp(A[2], B[2], q) : B[2];
        Object.assign(pa.hl.style, { left: (x - 4) + 'px', top: (B[1] + 3) + 'px', width: (w + 2) + 'px', height: (B[3] - 4) + 'px' });
        put(pa.hl, { o: 1 });
      } else put(pa.hl, { o: 0 });
    });
    put(bar, ap(t, 15.42, { dur: 0.5, y: 28, blur: 6 }, 16.85, { dur: 0.3, y: 30, blur: 4 }));
    const playing = P(t, 15.4, 15.55, E.std);
    put(pPlay, { o: 1 - playing, s: lerp(1, 0.25, playing), blur: playing * 4 });
    put(pPause, { o: playing, s: lerp(0.25, 1, playing), blur: (1 - playing) * 4 });
    tL.textContent = fmt(rt); tR.textContent = '−' + fmt(16376 - rt);
    pfill.style.width = (100 * rt / 16376) + '%';
    pane.style.height = (t > 17 ? 1300 : 880) + 'px';
  };
}

// =====================================================================================================
// S8 · On teal (21.1 – 25.3): "Ask it anything." · paste from any source · audio stays on the Mac.
// =====================================================================================================
let lockCenter = [960, 420];
const TEAL_BG = 'radial-gradient(ellipse at 50% 40%, #136a70 0%, #0F5E63 38%, #0A3F42 100%)';
function tealGlows(parent) {
  return blobs(parent, [
    { x: 1600, y: 120, r: 460, c: 'rgba(191,220,215,.22)', o: 1, sp: 0.4, ph: 1, dx: 70, dy: 40 },
    { x: 260, y: 980, r: 520, c: 'rgba(246,194,122,.16)', o: 1, sp: 0.33, ph: 3, dx: 60, dy: 30 },
  ]);
}
{
  const sc = scene(21.1, 25.32, { background: TEAL_BG });
  const gl = tealGlows(sc.root);
  const big = h('div', 'abs serif nowrap', sc.root, { left: 0, width: W, top: 452, textAlign: 'center', fontSize: 150, fontWeight: 600, letterSpacing: '-0.025em', lineHeight: 1 });
  const bigT = h('span', '', big, { display: 'inline-block', color: 'transparent', backgroundImage: 'linear-gradient(100deg, #F7F4EE 0%, #F7F4EE 42%, #F6C27A 50%, #F7F4EE 58%, #F7F4EE 100%)', backgroundSize: '320% 100%', WebkitBackgroundClip: 'text', backgroundClip: 'text', paddingBottom: '0.12em' }, 'Ask it anything.');
  // "Paste from [source]": the chip's label rolls and its width follows.
  const SOURCES = [
    { label: 'Spotify', link: 'open.spotify.com/episode/…' },
    { label: 'Apple Podcasts', link: 'podcasts.apple.com/…/acquired' },
    { label: 'YouTube', link: 'youtube.com/watch?v=…' },
    { label: 'RSS feeds', link: 'feeds.transistor.fm/acquired' },
  ];
  const sT = [22.44, 22.8, 23.16, 23.52];
  sT.forEach((x, i) => cue(i ? 'roll' : 'pop', x, { gain: 0.6 }));
  const row = h('div', 'abs nowrap', sc.root, { top: 368, height: 120, display: 'flex', alignItems: 'center', gap: '30px' });
  const pre = h('span', 'serif', row, { fontSize: 92, fontWeight: 600, color: 'var(--paper)', letterSpacing: '-0.02em' }, 'Paste from');
  const chip = h('span', '', row, { position: 'relative', height: 112, clipPath: 'inset(0 -800px 0 -40px)' });
  const chipBg = h('span', 'abs', chip, { left: 0, top: 0, height: 112, width: '100%', borderRadius: 28, background: 'rgba(255,255,255,.10)', border: '1.5px solid rgba(255,255,255,.2)' });
  void chipBg;
  const chipRoll = makeRoll(chip, sT.map((t, i) => ({ t, text: SOURCES[i].label })), { position: 'absolute', left: 32, top: 18, height: 76, font: '600 70px/76px var(--sans)', color: 'var(--paper)' });
  const card = h('div', 'abs', sc.root, { left: 960 - 470, top: 560, width: 940, height: 128, borderRadius: 28, background: 'rgba(0,0,0,.20)', border: '1px solid rgba(255,255,255,.10)' });
  h('div', 'abs', card, { left: 30, top: 42, width: 44, height: 44 }, `<svg viewBox="0 0 28 28" width="100%" height="100%"><path d="M12 16 L16 12 M10.5 13.5 L8 16a3.5 3.5 0 0 0 5 5l2.5-2.5 M17.5 14.5 L20 12a3.5 3.5 0 0 0-5-5l-2.5 2.5" fill="none" stroke="#BFDCD7" stroke-width="2.2" stroke-linecap="round"/></svg>`);
  const linkBox = h('div', 'abs', card, { left: 96, top: 38, height: 52, width: 800 });
  const linkRoll = makeRoll(linkBox, sT.map((t, i) => ({ t, text: SOURCES[i].link })), { position: 'absolute', left: 0, top: 0, font: '400 38px/52px var(--mono)', color: 'rgba(247,244,238,.88)' });
  let labelW = [];
  onMeasure(() => { const m = h('span', '', document.body, { position: 'absolute', font: '600 70px/76px var(--sans)', visibility: 'hidden' }); labelW = SOURCES.map(s => { m.textContent = s.label; return m.offsetWidth; }); m.remove(); });
  const lock = h('div', 'abs', sc.root, { left: 960 - 60, top: 300, width: 120, height: 140 });
  lock.innerHTML = `<svg viewBox="0 0 120 140" width="120" height="140" style="overflow:visible"><g id="shackle"><path d="M32 66 V44 a28 28 0 0 1 56 0 V66" fill="none" stroke="#F7F4EE" stroke-width="11" stroke-linecap="round"/></g><rect x="14" y="62" width="92" height="74" rx="18" fill="#F7F4EE"/><circle cx="60" cy="94" r="8" fill="#0F5E63"/><rect x="56" y="96" width="8" height="18" rx="4" fill="#0F5E63"/></svg>`;
  const shackle = lock.querySelector('#shackle');
  const priv = h('div', 'abs serif nowrap', sc.root, { left: 0, width: W, top: 500, textAlign: 'center', fontSize: 104, fontWeight: 600, color: 'var(--paper)', letterSpacing: '-0.02em' }, 'Your audio never leaves your Mac.');
  cue('shimmer', 21.62); cue('whoosh', 21.12, { len: 0.42, gain: 0.55 }); cue('lock', 24.22);
  sc.update = t => {
    const R = lerp(0, 2300, P(t, 21.15, 21.55, E.inOut));
    sc.root.style.clipPath = t < 21.55 ? `circle(${R}px at ${playLabelCenter[0]}px ${playLabelCenter[1]}px)` : 'none';
    blobsAt(gl, t);
    put(big, ap(t, 21.42, { dur: 0.6, y: 26, blur: 20, s: 0.96 }, 22.3, { dur: 0.22, y: -18, blur: 12 }));
    bigT.style.backgroundPosition = `${lerp(100, 0, P(t, 21.65, 22.4, E.inOut))}% 0`;
    const i = rollAt(chipRoll, t, 60, 0.3);
    rollAt(linkRoll, t, 30, 0.3);
    let w = labelW[0] || 300;
    if (i >= 0) { const pw = E.std(clamp((t - sT[i] + 0.03) / 0.22)); w = lerp(labelW[Math.max(0, i - 1)] || 0, labelW[i] || 0, i === 0 ? 1 : pw); }
    chip.style.width = (w + 64) + 'px';
    const rowW = pre.offsetWidth + 30 + w + 64;
    row.style.left = (960 - rowW / 2) + 'px';
    put(row, ap(t, 22.36, { dur: 0.45, y: 20, blur: 14 }, 23.84, { dur: 0.22, y: -16, blur: 10 }));
    put(card, ap(t, 22.46, { dur: 0.45, y: 20, blur: 10 }, 23.86, { dur: 0.22, y: -16, blur: 10 }));
    put(lock, ap(t, 23.96, { dur: 0.45, y: 18, blur: 10, s: 0.9 }));
    shackle.setAttribute('transform', `translate(0 ${lerp(-16, 0, P(t, 24.2, 24.32, E.std))})`);
    put(priv, ap(t, 24.08, { dur: 0.55, y: 22, blur: 16 }));
    lockCenter = centerOf(lock);
  };
}

// =====================================================================================================
// S9 · The questions answered, then the whole summary as a wall; the line (24.9 – 27.75).
// =====================================================================================================
let periodCenter = [1500, 560];
{
  const sc = scene(24.9, 27.75, { background: 'var(--paper)', perspective: '1800px' });
  const world = h('div', 'cam', sc.root, { transformStyle: 'preserve-3d' });
  // The wall: one card for each point in the episode's summary (168 in all), around the conversation.
  const wall = h('div', 'full', world, { transformStyle: 'preserve-3d' });
  const pts = C.points.slice(1).map(p => ({ ...splitLead(p.text), start: p.start })).filter(p => p.lead && p.lead.length < 34);
  const CW = 980, CH = 300, GX = 1040, GY = 350;
  const cards = [];
  let k = 0;
  for (let r = -5; r <= 5; r++) for (let c = -4; c <= 4; c++) {
    if (c === 0 && r >= -1 && r <= 1) continue;
    const p = pts[k++ % pts.length];
    const x = 960 + c * GX - CW / 2 + (r % 2 ? GX / 2 : 0), y = 540 + r * GY - CH / 2;
    const el = h('div', 'abs elev', wall, { left: x, top: y, width: CW, height: CH, borderRadius: 34, padding: '44px 52px' });
    el.innerHTML = `<div style="display:flex;align-items:center;gap:18px"><span class="tpill" style="font-size:34px;padding:10px 16px;border-radius:12px">${fmt(p.start)}</span><span class="dot" style="width:18px;height:18px;background:var(--sp${Math.abs(r + c) % 3})"></span></div>
      <div style="margin-top:28px;font:600 58px/1.1 var(--serif);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${p.lead.replace(/:$/, '')}</div>`;
    cards.push({ el, d: Math.hypot(c, r * 0.9) });
  }
  // The conversation from the opening, now answered.
  const convo = h('div', 'abs elev', world, { left: 960 - 520, top: 540 - 345, width: 1040, height: 690, borderRadius: 40 });
  const panelBg = h('div', 'abs', convo, { inset: 0, borderRadius: 40, background: 'var(--paper)' });
  const ANS = [
    `<span>It saved Disney Animation.</span><span class="tpill" style="margin-left:14px;font-size:24px">2:44:24</span>`,
    `<span class="dot" style="background:var(--sp0);width:14px;height:14px"></span><span style="font-weight:600;color:var(--sp0);margin-left:12px">Ben Gilbert</span><span style="color:var(--muted);margin-left:12px;font-size:26px">suggested · 80%</span>`,
    `<span style="width:28px;height:28px;display:inline-block;margin-right:12px">${ICON.play('#0F5E63')}</span><span style="color:var(--accent);font-weight:600">Play from 2:44:24</span>`,
  ];
  const pairs = QUESTIONS.map((q, i) => {
    const top = 34 + i * 214;
    const B = bubble(convo, q, { left: 60, top });
    const a = h('div', 'abs', convo, { left: 150, top: top + 116, height: 72, borderRadius: 26, padding: '0 28px 0 76px', background: 'var(--accentSoft)', display: 'flex', alignItems: 'center', font: '400 32px/1 var(--sans)', whiteSpace: 'nowrap' }, ANS[i]);
    const av = h('div', 'abs', a, { left: 14, top: 12, width: 48, height: 48, borderRadius: 24, background: 'var(--accent)' });
    const mk = markSVG(av, 30, 18, 3.4, '#F7F4EE'); mk.svg.style.left = '5.6px'; mk.svg.style.top = '11.6px';
    return { B, a };
  });
  onMeasure(() => pairs.forEach(({ B }) => { B.w = B.txt.scrollWidth + 56; }));
  const tA = [25.18, 25.42, 25.66];
  tA.forEach((x, i) => cue('pop', x, { pitch: 1 + i * 0.12, gain: 0.55 }));
  // Paper rises over the far side of the wall so the line reads cleanly.
  const veil = h('div', 'full', sc.root, { background: 'linear-gradient(180deg, var(--paper) 0%, rgba(247,244,238,.92) 38%, rgba(247,244,238,0) 72%)' });
  // The line, delivered on the wall's plane and turned to face us.
  const line = h('div', 'abs serif nowrap', sc.root, { left: 0, width: W, top: 250, textAlign: 'center', fontSize: 124, lineHeight: 1.08, fontWeight: 600, letterSpacing: '-0.025em', transformStyle: 'preserve-3d' });
  const LINE = [['Every', ''], ['episode,', ''], ['searchable', 'var(--accent)'], ['and', ''], ['quotable', 'var(--accent)']];
  const lw = LINE.map(([w, c], i) => { const e = h('span', '', line, { display: 'inline-block', color: c || 'var(--ink)', marginRight: i < LINE.length - 1 && i !== 1 ? '0.26em' : '0' }); e.textContent = w; if (i === 1) h('br', '', line); return e; });
  const period = h('span', '', line, { display: 'inline-block', color: 'var(--accent)' }, '.');
  cue('whoosh', 25.95, { len: 0.75, gain: 0.5 }); cue('whoosh', 26.5, { len: 0.6, gain: 0.35 });
  sc.update = t => {
    const R = lerp(0, 2300, P(t, 24.9, 25.32, E.inOut));
    sc.root.style.clipPath = t < 25.32 ? `circle(${R}px at ${lockCenter[0]}px ${lockCenter[1]}px)` : 'none';
    const z = P(t, 25.95, 26.7, E.cam), back = P(t, 26.55, 27.3, E.inOut);
    const s = lerp(1.0, 0.36, z) * lerp(1, 0.85, back), rx = lerp(0, 52, z), rz = lerp(0, -22, z);
    world.style.transform = `translate(960px,${540 + 260 * back}px) rotateX(${rx}deg) rotateZ(${rz}deg) scale(${s}) translate(-960px,-540px)`;
    put(world, { o: 1, blur: back * 3 });
    world.style.transform = `translate(960px,${540 + 380 * back}px) rotateX(${rx}deg) rotateZ(${rz}deg) scale(${s}) translate(-960px,-540px)`;
    world.style.opacity = lerp(1, 0.5, back);
    put(veil, { o: P(t, 26.5, 27.1, E.inOut) });
    cards.forEach(cd => put(cd.el, { o: P(t, 25.95 + cd.d * 0.05, 26.35 + cd.d * 0.05, E.lin) }));
    put(panelBg, { o: 1 - P(t, 25.95, 26.3, E.lin) });
    pairs.forEach(({ B, a }, i) => { bubbleAt(B, t, -10, -10); put(a, ap(t, tA[i], { dur: 0.4, y: 14, blur: 8, s: 0.96 })); });
    // The line lies on the wall's plane, then turns flat to face the viewer.
    const f = P(t, 26.45, 27.1, E.cam);
    line.style.transform = `translate(0,${lerp(260, 0, f)}px) rotateX(${lerp(52, 0, f)}deg) rotateZ(${lerp(-22, 0, f)}deg) scale(${lerp(0.55, 1, f)})`;
    lw.forEach((e, i) => put(e, { o: P(t, 26.45 + i * 0.08, 26.75 + i * 0.08, E.lin), blur: (1 - P(t, 26.45 + i * 0.08, 26.85 + i * 0.08)) * 10 }));
    put(period, { o: P(t, 26.85, 27.0, E.lin), s: 1 + 0.6 * P(t, 27.2, 27.32, E.std) });
    periodCenter = (() => { const r = rectOf(period); return [r.left + r.width / 2, r.bottom - r.height * 0.24]; })();
  };
}

// =====================================================================================================
// S10 · End card (27.3 – 30): the icon and wordmark, the promise typed out, the link.
// =====================================================================================================
{
  const sc = scene(27.28, 30.01, { background: TEAL_BG });
  const gl = tealGlows(sc.root);
  const lock = h('div', 'abs', sc.root, { left: 0, width: W, top: 300, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '40px' });
  const icon = h('img', '', lock, { width: 184, height: 184, filter: 'drop-shadow(0 18px 30px rgba(0,0,0,.25))' }); icon.src = 'assets/icon.png';
  const word = h('div', 'serif nowrap', lock, { fontSize: 164, fontWeight: 600, letterSpacing: '-0.025em', color: 'var(--paper)' }, 'Wavepod');
  const TAG = 'Read any podcast, ask it anything.';
  const tag = h('div', 'abs serif nowrap', sc.root, { left: 0, width: W, top: 540, textAlign: 'center', fontSize: 54, color: 'rgba(247,244,238,.92)' });
  const tagT = h('span', '', tag); const tagC = h('span', 'caret', tag, { background: 'var(--paper)', width: '3px' });
  const tt = typeTimes(TAG, 28.06, 46, 41);
  const tDone = tt[tt.length - 1];
  const cta = h('div', 'abs', sc.root, { top: 676, height: 100, borderRadius: 50, background: '#fff', display: 'flex', alignItems: 'center', gap: '18px', padding: '0 14px 0 34px', boxShadow: '0 14px 40px rgba(0,0,0,.25)' });
  cta.innerHTML = `<span style="font:600 32px/1 var(--sans);color:var(--accent)">Free and open source</span><span style="width:6px;height:6px;border-radius:3px;background:var(--rule)"></span>`;
  const url = h('span', '', cta, { font: '500 31px/1 var(--mono)', color: 'var(--ink)', textDecorationThickness: '2px', textUnderlineOffset: '6px' }, 'github.com/concava/wavepod');
  const go = h('span', '', cta, { width: 70, height: 70, borderRadius: 35, background: 'var(--accent)', padding: '17px', display: 'inline-block' }, ICON.arrow('#fff'));
  cue('final', 27.62); cue('pop', 28.92, { pitch: 1.3, gain: 0.5 });
  cursorWindows.push([29.02, 30.1]);
  cursorTrack.push({ t: 29.02, at: () => [1520, 1010] }, { t: 29.06, at: () => centerOf(go), move: 0.42 });
  clicks.push(29.6);
  sc.update = t => {
    const R = lerp(9, 2300, P(t, 27.3, 27.72, E.inOut));
    sc.root.style.clipPath = t < 27.72 ? `circle(${R}px at ${periodCenter[0]}px ${periodCenter[1]}px)` : 'none';
    blobsAt(gl, t);
    put(icon, ap(t, 27.6, { dur: 0.6, y: 10, blur: 14, s: 0.72 }));
    put(word, ap(t, 27.72, { dur: 0.6, dx: -28, y: 0, blur: 16 }));
    tagT.textContent = TAG.slice(0, countAt(tt, t));
    tagC.style.visibility = t >= 28.0 && t < 29.0 && (t < tDone + 0.05 || blinkOn(t, tDone + 0.05)) ? 'visible' : 'hidden';
    cta.style.left = (960 - cta.offsetWidth / 2) + 'px';
    put(cta, { ...ap(t, 28.9, { dur: 0.5, y: 16, blur: 10, s: 0.95 }), s: ap(t, 28.9, { dur: 0.5, s: 0.95 }).s * (t >= 29.6 && t < 29.72 ? 0.97 : 1) });
    const hov = P(t, 29.44, 29.56, E.lin);
    url.style.textDecoration = hov > 0.5 ? 'underline' : 'none';
    go.style.background = hov > 0.5 ? 'var(--teal-deep)' : 'var(--accent)';
  };
}

// ---------- Cursor and click rings (screen space, positions read live from the scene) ----------
const cursor = document.getElementById('cursor');
const ringPool = clicks.map(() => h('div', 'ring', document.body));
clicks.forEach(t => cue('click', t));
function cursorAt(t) {
  let i = -1;
  for (let k = 0; k < cursorTrack.length; k++) if (cursorTrack[k].t <= t) i = k;
  if (i < 0) return null;
  const wp = cursorTrack[i];
  const to = wp.at();
  if (!wp.move || i === 0) return to;
  const p = P(t, wp.t, wp.t + wp.move, E.inOut);
  if (p >= 1) return to;
  const from = (() => { const prev = cursorTrack[i - 1]; return prev.at(); })();
  const dx = to[0] - from[0], dy = to[1] - from[1], len = Math.hypot(dx, dy);
  const arc = Math.sin(Math.PI * p) * len * 0.08;
  return [lerp(from[0], to[0], p) - dy / (len || 1) * arc, lerp(from[1], to[1], p) + dx / (len || 1) * arc];
}

// ---------- Render ----------
let measured = false;
window.render = function (t) {
  if (!measured) { measured = true; for (const f of measures) f(); }
  for (const sc of scenes) {
    const on = t >= sc.t0 && t < sc.t1;
    const d = on ? 'block' : 'none';
    if (sc.root.style.display !== d) sc.root.style.display = d;
    if (on) sc.update(t);
  }
  // Cursor
  let vis = 0;
  for (const [a, b] of cursorWindows) vis = Math.max(vis, P(t, a, a + 0.15, E.lin) * (1 - P(t, b - 0.15, b, E.lin)));
  const pos = vis > 0 ? cursorAt(t) : null;
  if (pos) {
    const press = clicks.some(c => t >= c && t < c + 0.12);
    cursor.style.transform = `translate(${pos[0] - 6}px,${pos[1] - 4}px) scale(${press ? 0.86 : 1})`;
    cursor.style.opacity = vis; cursor.style.visibility = 'visible';
  } else cursor.style.visibility = 'hidden';
  clicks.forEach((c, i) => {
    const el = ringPool[i], p = P(t, c, c + 0.5, E.out);
    if (t < c || p >= 1 || !pos) { el.style.visibility = 'hidden'; return; }
    const r = lerp(8, 46, p);
    Object.assign(el.style, { visibility: 'visible', left: (pos[0] - r) + 'px', top: (pos[1] - r) + 'px', width: 2 * r + 'px', height: 2 * r + 'px', opacity: 1 - p });
  });
  // Film grain moves every frame.
  const fr = Math.floor(t * 60), g = document.getElementById('grain');
  g.style.transform = `translate(${(fr * 37) % 64 - 32}px,${(fr * 53) % 64 - 32}px)`;
  document.getElementById('vignette').style.opacity = t >= 21.3 && t < 25.1 || t >= 27.5 ? 0.6 : 1;
};
window.DURATION = DURATION;
window.READY = (async () => {
  await document.fonts.ready;
  await Promise.all([...document.images].map(i => i.complete ? 0 : new Promise(r => { i.onload = i.onerror = r; })));
  await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
  window.render(0);
  return true;
})();
