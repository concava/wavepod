# Wavepod: 30-second launch film

`wavepod-launch-30s.mp4`: 1920 × 1080, 60 fps, H.264 with AAC stereo at 48 kHz, loudness −16 LUFS, true peak −1.5 dBTP.

The film follows the structure of a reference launch film, adapted to Wavepod:

1. The problem.
2. The pile-up.
3. The turn.
4. The reveal.
5. The workflow in live UI.
6. A montage.
7. The payoff.
8. The end card.

Everything is drawn in code, with the app's own fonts and colours. Every frame can be rendered alone.

## Storyboard

| Time | Shot | What moves |
| --- | --- | --- |
| 0.0–3.4 | "The best part was somewhere in hour three." | The line types out in New York. The camera pushes in and tilts onto "hour three." while the other words fall out of focus. The words squash into a line. |
| 3.4–6.4 | Scrubbing | The line becomes the real waveform of the 4:32:56 Disney episode. The playhead whips between hours, with motion blur and a rolling timecode. Three late-night questions arrive over the blurred waveform. |
| 6.4–8.4 | "What if you could read it?" | The line types out. The transcript's word highlight follows it word by word, then selects all and deletes it. |
| 8.4–10.4 | **Meet Wavepod.** | The caret tips over into the wave mark from `WaveShape`. The mark draws itself, rings out and settles into a straight line. Rings ripple out, and the title sharpens in. This is the beat drop. |
| 10.4–13.4 | Find and transcribe | The mark shrinks into the search field as it opens. ⌘K is pressed on the amber keycap, "Acquired Disney" is typed, and Transcribe is clicked. The progress card rolls through the app's real stages ("Downloading", "Transcribing window 6", "Identifying speakers, window 3", "Summarizing"). Transcript text streams past behind it. |
| 13.4–17.4 | Summary to moment | The episode pane arrives with three real summary points. The pointer hovers "Broken profit engine", and the play label (08:20) appears. On the click, the transcript pane slides in: Ben Gilbert (suggested · 80%) speaks the cited sentence, and the word highlight follows the real word timings. The player bar rises. |
| 17.4–21.4 | Ask | The pointer clicks into "Ask or search this episode" and types "Why did the Pixar deal matter so much for Disney?". The status rolls ("Preparing transcript…", "Reading transcript 2 of 6…"). The real answer arrives: "Restoring Disney's creative core". A hover shows the quote tooltip. Clicking 2:44:24 opens a teal circle that fills the screen. |
| 21.4–24.9 | On teal | "Ask it anything." with a light sweep. "Paste from Spotify / Apple Podcasts / YouTube / RSS feeds", with a rolling chip and link. A lock closes on "Your audio never leaves your Mac." |
| 24.9–27.3 | Payoff and the wall | A wipe back to paper shows the three questions from the opening, each now answered. The camera pulls back and tilts: the conversation is one card in a wall of the episode's summary points. "Every episode, searchable and quotable." turns to face the viewer, and its period grows into the wipe. |
| 27.3–30.0 | End card | The icon and the Wavepod wordmark, then "Read any podcast. Ask it anything." types out. The pointer clicks "Free for Mac · github.com/concava/wavepod". |

## Motion system

These come from `WavepodKit/Sources/UI/Theme.swift`:

- **Easing:** `cubic-bezier(0.2, 0, 0, 1)` (`Motion.standard`) for anything moving into place. A slower in-out curve for the camera.
- **Entrances:** rise 12–30 px, sharpen from a 6–20 px blur and fade in, over 0.35–0.6 s. Lists are staggered by 100 ms.
- **Exits:** shorter than entrances, 0.15–0.25 s.
- **Presses:** scale to 0.96. Hover fills use `selection`.

The film always has three layers of motion: the primary action; secondary motion (pointer, rings, highlights, shadows); and an ambient layer (drifting colour fields, film grain, a slow camera drift).

## What is real

- **Episode and text.** The episode, its artwork and duration, the summary points, the transcript text, the speaker labels and word timings, and the Pixar question and answer all come from the Disney (Acquired) episode in the local library.
- **Waveform.** The waveform is that episode's own audio, measured at four values per second.
- **App wording.** Status messages, labels and the "Every episode, searchable and quotable" line are the app's own wording.
- **Look.** Colours are the app's tokens. Fonts are New York, SF Pro and SF Mono, read from macOS and not bundled.
- **Illustrative content.** The three opening questions and their times ("11:42 PM") are illustrative. The source links in the teal montage are examples of each kind of link, except `feeds.transistor.fm/acquired`, which is the episode's real feed.

## Sound

`audio.py` synthesizes the score and the sound design from scratch, with no samples:

- **Score.** 120 BPM in D major. Beats fall on 0.4 + 0.5k s, so every cut lands on the grid.
- **Arrangement.** A quiet pad under the typing, and a tense clock under the scrubbing. A riser leads into the reveal; the drop lands on "Meet Wavepod". A groove of soft kick, snaps, hats and shaker runs under a bass line and felt-pluck arpeggios. The arrangement lifts on teal and breaks down for the payoff. It builds into a breath of silence, then a final D major 9 chord.
- **Sound effects.** Every keystroke, click, pop, status roll, scrub and wipe has its own sound, timed from `cues.json`. The film writes that file.

## How it is made

The film is a web page. `film.js` defines a `render(t)` function that draws any moment of the film from scratch: positions, blurs, typing, the camera, the pointer. No CSS animation or timers are involved, so every frame is exact and can be rendered alone. `render.cjs` opens the page in headless Chrome, calls `render(t)` for each of the 1,800 frames (60 fps), takes a screenshot and pipes it to FFmpeg. Six Chrome processes render in parallel.

| File | What it does |
| --- | --- |
| `index.html` | The stage, the app's colour tokens and fonts (New York, SF Pro, SF Mono from `/System/Library/Fonts`) |
| `film.js` | The ten shots, the easing curves, typing, text rolls, the camera, the pointer and the sound cues |
| `render.cjs` | Renders stills, the full video, or `cues.json` for the sound |
| `audio.py` | Synthesizes the score and sound effects from `cues.json`: `music.wav`, `sfx.wav`, `mix.wav` |
| `master.sh` | Normalizes the mix to −16 LUFS and encodes the final MP4 and the poster |
| `sheet.py` | Builds contact sheets from stills for reviewing frames |
| `assets/` | The episode artwork, the app icon, film grain, the episode content and its waveform |
| `storyboard.jpg` | One frame from each shot |

`assets/content.js` holds excerpts of the Disney (Acquired) episode from the Wavepod library: summary points, transcript lines with word timings, and the saved answer. `assets/envelope.js` is the episode audio's loudness at four values per second. Both were exported once from `~/Library/Application Support/wavepod/`.

## Rebuild

You need macOS (for the fonts), Google Chrome in `/Applications`, Node.js, FFmpeg, and Python 3 with NumPy and SciPy.

```sh
npm install
pip3 install numpy scipy
npm run cues      # cues.json: when each keystroke, click and wipe happens
npm run audio     # music.wav, sfx.wav and mix.wav
npm run video     # film-silent.mov (ProRes, about 1.3 GB)
npm run master    # wavepod-launch-30s.mp4 and wavepod-launch-poster.jpg
```

The included WAV files are the finished soundtrack, so you can skip `npm run audio`. To check single frames, run `node render.cjs --stills 9.6,15.0,29.7`. The PNGs go to `stills/`. To compare them side by side, run `python3 sheet.py sheet.png stills/*.png`.

To change the film, edit a shot in `film.js`, render the stills around that moment, and look at them before rendering the whole video. If you change any timing, run `npm run cues` and `npm run audio` again so the sounds follow the picture.
