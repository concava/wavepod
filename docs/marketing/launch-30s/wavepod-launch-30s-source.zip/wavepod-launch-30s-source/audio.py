"""Score and sound design for the Wavepod film, synthesized from scratch (no samples).

120 BPM, D major. Beats fall at 0.4 + 0.5 k seconds so the cuts at 3.4, 8.4, 13.4, 17.4 and 21.4 land on the grid.
Sound effects follow cues.json, which the film writes: every keystroke, click, pop and roll has its own sound.
Writes music.wav, sfx.wav and mix.wav (48 kHz, 24-bit stereo, before loudness normalization).
"""
import json, sys, wave
import numpy as np
from scipy import signal

SR = 48000
DUR = 30.0
N = int(SR * DUR)
rng = np.random.default_rng(11)
here = sys.argv[1] if len(sys.argv) > 1 else '.'
cues = json.load(open(f'{here}/cues.json'))

def mtof(m): return 440.0 * 2 ** ((m - 69) / 12)
def tt(d): return np.arange(int(d * SR)) / SR

class Bus:
    def __init__(self): self.x = np.zeros((2, N))
    def add(self, sig, at, gain=1.0, pan=0.0):
        i = int(round(at * SR))
        if i >= N: return
        if sig.ndim == 1: sig = np.vstack([sig, sig])
        sig = sig[:, :max(0, N - i)]
        if i < 0: sig = sig[:, -i:]; i = 0
        l = np.cos((pan + 1) * np.pi / 4) * np.sqrt(2); r = np.sin((pan + 1) * np.pi / 4) * np.sqrt(2)
        self.x[0, i:i + sig.shape[1]] += sig[0] * gain * l
        self.x[1, i:i + sig.shape[1]] += sig[1] * gain * r

def lp(x, f, order=2): b, a = signal.butter(order, f / (SR / 2), 'low'); return signal.lfilter(b, a, x)
def hp(x, f, order=2): b, a = signal.butter(order, f / (SR / 2), 'high'); return signal.lfilter(b, a, x)
def bp(x, f1, f2, order=2): b, a = signal.butter(order, [f1 / (SR / 2), f2 / (SR / 2)], 'band'); return signal.lfilter(b, a, x)

def reverb_ir(rt=1.8, pre=0.012, bright=6000):
    t = tt(rt * 1.2)
    ir = np.vstack([rng.standard_normal(len(t)), rng.standard_normal(len(t))]) * np.exp(-6.9 * t / rt)
    ir = np.vstack([lp(ir[0], bright), lp(ir[1], bright)])
    ir[:, :int(pre * SR)] = 0
    return ir / np.sqrt((ir ** 2).sum() / 2) * 0.35
IR = reverb_ir()
def reverb(x, ir=IR): return np.vstack([hp(signal.fftconvolve(x[c], ir[c])[:N], 180) for c in range(2)])

# ---------------------------------------------------------------- instruments
def pad_note(m, d, att=0.6, rel=1.2, bright=1.0):
    t = tt(d + rel)
    out = np.zeros((2, len(t)))
    for ch, det in ((0, -5), (1, 5)):
        for v in (-1, 0, 1):
            f = mtof(m) * 2 ** ((det * v + det * 0.3) / 1200)
            ph = rng.uniform(0, 2 * np.pi)
            for k in range(1, 9):
                if f * k > 5000: break
                out[ch] += np.sin(2 * np.pi * f * k * t + ph * k) / k ** (1.9 - 0.5 * bright)
    env = np.minimum(1, t / att) * np.where(t < d, 1, np.exp(-(t - d) / (rel / 3)))
    env *= 1 + 0.08 * np.sin(2 * np.pi * 0.35 * t)
    return out * env / 6

def pluck(m, d=0.6, bright=1.0, tau=0.32):
    t = tt(d)
    f = mtof(m)
    x = np.sin(2 * np.pi * f * t) + 0.32 * bright * np.sin(4 * np.pi * f * t) * np.exp(-t / (tau * 0.4)) \
        + 0.12 * bright * np.sin(6 * np.pi * f * t + 0.3) * np.exp(-t / (tau * 0.25))
    env = np.minimum(1, t / 0.003) * np.exp(-t / tau)
    click = rng.standard_normal(len(t)) * np.exp(-t / 0.002) * 0.15
    return (x * env + hp(click, 2000)) * 0.5

def bell(m, d=2.5, idx=2.2, ratio=3.5, tau=0.9):
    t = tt(d)
    f = mtof(m)
    mod = np.sin(2 * np.pi * f * ratio * t) * idx * np.exp(-t / (tau * 0.5))
    x = np.sin(2 * np.pi * f * t + mod) * np.exp(-t / tau) * np.minimum(1, t / 0.002)
    return x * 0.4

def bass_note(m, d):
    t = tt(d + 0.08)
    f = mtof(m)
    x = np.sin(2 * np.pi * f * t) + 0.25 * np.sin(4 * np.pi * f * t)
    x = np.tanh(1.6 * x) / 1.2
    env = np.minimum(1, t / 0.006) * np.where(t < d, 0.75 + 0.25 * np.exp(-t / 0.12), 0) \
        + np.where(t >= d, (0.75) * np.exp(-(t - d) / 0.025), 0)
    return lp(x * env, 900) * 0.55

def kick(gain=1.0):
    t = tt(0.5)
    f = 46 + 95 * np.exp(-t / 0.045)
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = np.sin(ph) * np.exp(-t / 0.28) + hp(rng.standard_normal(len(t)), 3000) * np.exp(-t / 0.003) * 0.25
    return np.tanh(1.4 * x) * gain

def snap(gain=1.0):
    t = tt(0.3)
    n = rng.standard_normal(len(t))
    env = sum(np.exp(-np.maximum(0, t - o) / 0.012) * (t >= o) for o in (0, 0.009, 0.019)) * 0.6 + np.exp(-t / 0.09) * 0.4
    return bp(n, 900, 4200) * env * 0.5 * gain

def hat(open_=False, gain=1.0):
    t = tt(0.4 if open_ else 0.08)
    x = hp(rng.standard_normal(len(t)), 7000, 4) * np.exp(-t / (0.16 if open_ else 0.025))
    return x * 0.35 * gain

def shaker(gain=1.0):
    t = tt(0.09)
    x = bp(rng.standard_normal(len(t)), 5000, 11000) * np.minimum(1, t / 0.012) * np.exp(-t / 0.03)
    return x * 0.22 * gain

# ---------------------------------------------------------------- score
music = Bus()
B = 0.5  # one beat
def beat(k): return 0.4 + k * B
CH = {  # pad voicing, bass root, arpeggio tones
    'D':  ([57, 61, 64, 66], 38, [62, 66, 69, 73, 76]),
    'Bm': ([54, 57, 61, 62], 35, [59, 62, 66, 69, 73]),
    'G':  ([54, 57, 59, 62], 43, [55, 59, 62, 66, 69]),
    'A':  ([52, 57, 59, 61], 45, [57, 61, 64, 66, 71]),
    'Asus': ([52, 57, 59, 62], 45, [57, 62, 64, 69, 71]),
    'F#m': ([52, 57, 61, 64], 42, [57, 61, 64, 69, 73]),
}
# (start, length, chord)
intro = [(0.0, 2.4, 'D'), (2.4, 2.0, 'Bm'), (4.4, 2.0, 'G'), (6.4, 2.0, 'Asus')]
groove = [(8.4, 2, 'D'), (10.4, 2, 'Bm'), (12.4, 2, 'G'), (14.4, 2, 'A'), (16.4, 2, 'D'), (18.4, 2, 'Bm'), (20.4, 0.5, 'G'), (20.9, 0.5, 'A')]
lift = [(21.4, 1.0, 'G'), (22.4, 1.0, 'A'), (23.4, 1.0, 'Bm'), (24.4, 0.5, 'F#m')]
callback = [(24.9, 1.0, 'G')]
build = [(25.9, 1.0, 'A'), (26.9, 0.4, 'Asus')]

# Pad: everywhere except the breath before the end card. It has its own bus so it can be filtered and shaped.
pads = Bus()
for s, d, c in intro + groove + lift + callback + build:
    notes, root, _ = CH[c]
    g = 0.42
    for m in notes: pads.add(pad_note(m, d, att=0.9 if s < 1 else 0.25, rel=0.9, bright=0.7 if s < 8.4 else 1.0), s, g, pan=rng.uniform(-0.3, 0.3))
    pads.add(pad_note(root + 12, d, att=0.4, rel=0.6, bright=0.3), s, g * 0.45)
_t = np.arange(N) / SR
# Quiet under the opening (typing carries it), opening up into the riser, full from the drop.
pad_gain = np.interp(_t, [0, 1.5, 6.4, 8.3, 8.4, 30], [0.0, 0.38, 0.42, 0.62, 0.8, 0.8])
pads.x = np.vstack([lp(hp(pads.x[c], 150), 4200) for c in range(2)]) * pad_gain
music.x += pads.x

# Tension under the scrubbing (3.4 – 6.4): a pulsing low D and a nervous clock.
t = tt(3.0); drone = np.sin(2 * np.pi * mtof(38) * t) * (0.6 + 0.4 * np.sin(2 * np.pi * 4 * t)) * np.minimum(1, t / 0.4) * np.minimum(1, (3.0 - t) / 0.3)
music.add(lp(drone, 300) * 0.16, 3.4)
for k in range(24):
    music.add(hat(gain=0.28 + 0.2 * (k % 2 == 0)), 3.4 + k * 0.125, pan=0.4)

# The turn (6.4 – 8.4): three soft notes, then the riser handles the rest.
for at, m in ((6.55, 74), (6.9, 73), (7.25, 69)): music.add(pluck(m, 1.2, 0.6, 0.5), at, 0.22, pan=0.2)

# Bass and arpeggio through the groove and the lift.
def arp(sec, oct_up=False, gain=0.2, dens=1):
    for s, d, c in sec:
        tones = CH[c][2]
        steps = int(round(d / (B / 2 / dens)))
        order = [0, 1, 2, 3, 4, 3, 2, 1]
        for k in range(steps):
            m = tones[order[k % len(order)]] + (12 if oct_up else 0)
            acc = 1.0 if k % 4 == 0 else 0.7
            music.add(pluck(m, 0.5, 0.9, 0.22), s + k * B / 2 / dens, gain * acc, pan=0.35 * np.sin(k * 0.9))
arp([x for x in groove if x[0] >= 8.9] + [(8.65, 1.75, 'D')], gain=0.17)
arp(lift, gain=0.17); arp(lift, oct_up=True, gain=0.08)
arp(build, gain=0.15, dens=2)

BASS_PAT = [(0, 1.0), (1.5, 0.5), (2.5, 0.4), (3, 0.9)]
for s, d, c in groove[1:] + lift + build:
    root = CH[c][1]
    for b0, ln in BASS_PAT:
        at = s + b0 * B
        if at < s + d - 0.01: music.add(bass_note(root, min(ln * B, s + d - at) * 0.95), at, 0.5)
music.add(bass_note(38, 1.9), 8.4, 0.55)

# Drums.
def drums(t0, t1, kick_on=(0, 2), snaps=(1, 3), hats=True, open_off=False, shake=False, kg=0.9):
    k = 0
    while beat(k) < t1 - 1e-6:
        at = beat(k)
        if at >= t0 - 1e-6:
            pos = k % 4
            if pos in kick_on: music.add(kick(kg), at, 0.9)
            if pos in snaps: music.add(snap(0.8), at, 0.5, pan=-0.05)
            if hats:
                music.add(hat(gain=0.8), at, 0.5, pan=0.3)
                music.add(hat(open_=open_off, gain=0.6 if open_off else 0.45), at + B / 2, 0.5, pan=0.35)
            if shake:
                for q in range(4): music.add(shaker(0.9 if q == 2 else 0.55), at + q * B / 4, 0.6, pan=-0.4)
        k += 1
drums(8.4, 10.4, kick_on=(0,), snaps=(), hats=False)
drums(10.4, 13.4)
drums(13.4, 17.15, shake=True)
for q in range(4): music.add(snap(0.4 + q * 0.15), 17.15 + q * 0.0625, 0.45)  # a small fill into Ask
drums(17.4, 21.4, shake=True, kick_on=(0, 2, 3))
drums(21.4, 24.9, open_off=True, shake=True, kick_on=(0, 1, 2, 3))
drums(24.9, 25.9, kick_on=(0,), snaps=(), hats=False)
drums(25.9, 26.9, kick_on=(0, 1, 2, 3), snaps=(1, 3), hats=True)
for q in range(8): music.add(snap(0.3 + q * 0.09), 26.9 + q * 0.05, 0.5)  # roll into the breath

# Callback answers: the three pops become rising notes.
for at, m in ((25.18, 74), (25.42, 78), (25.66, 81)): music.add(bell(m, 1.8, 1.4, 2.0, 0.6), at, 0.22, pan=0.15)

# The end card (27.62): a full D major 9 chord, sub, and a rising arpeggio that rings out.
for m in (50, 57, 62, 66, 69, 73, 76): music.add(pad_note(m, 1.6, att=0.04, rel=1.4, bright=1.1), 27.62, 0.42, pan=rng.uniform(-0.4, 0.4))
for m in (38, 50): music.add(bass_note(m, 1.4), 27.62, 0.5)
for i, m in enumerate((62, 66, 69, 73, 76, 81, 85, 88)): music.add(bell(m, 2.2, 1.6, 3.5, 0.8), 27.66 + i * 0.09, 0.13 * (1 - i * 0.05), pan=-0.5 + i * 0.14)
music.add(kick(1.0), 27.62, 1.0)

# ---------------------------------------------------------------- sound effects from the film's cues
sfx = Bus()
def noise_burst(d, f1, f2, decay):
    t = tt(d); return bp(rng.standard_normal(len(t)), f1, f2) * np.exp(-t / decay)
def key_snd(ch):
    t = tt(0.06)
    body = noise_burst(0.06, 1800, 6500, 0.008) * 0.6 + bp(rng.standard_normal(len(t)), 300, 900) * np.exp(-t / 0.012) * 0.5
    if ch == ' ': body = lp(body, 2500) * 1.3
    return body * rng.uniform(0.6, 1.0)
def click_snd():
    t = tt(0.05)
    a = np.sin(2 * np.pi * 2200 * t) * np.exp(-t / 0.004)
    b = np.zeros_like(t); i = int(0.018 * SR); b[i:] = np.sin(2 * np.pi * 1600 * t[:-i]) * np.exp(-t[:-i] / 0.004) * 0.6
    return (a + b + noise_burst(0.05, 3000, 9000, 0.002) * 0.4) * 0.5
def pop_snd(p=1.0):
    t = tt(0.18)
    f = 520 * p + 380 * p * np.exp(-t / 0.02)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.05) * np.minimum(1, t / 0.002) * 0.5
def tick_snd(p=1.0):
    t = tt(0.04)
    return np.sin(2 * np.pi * 3200 * p * t) * np.exp(-t / 0.006) * 0.4
def whoosh_snd(d=0.6):
    t = tt(d)
    n = rng.standard_normal(len(t))
    env = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 1.6
    fc = 600 + 2600 * np.sin(np.pi * np.clip(t / d, 0, 1))
    out = np.zeros_like(n)
    for k in range(0, len(t), 512):  # time-varying band-pass, block by block
        seg = n[max(0, k - 256):k + 512]
        b, a = signal.butter(2, [max(80, fc[k] * 0.55) / (SR / 2), min(15000, fc[k] * 1.6) / (SR / 2)], 'band')
        out[k:k + 512] = signal.lfilter(b, a, seg)[-len(out[k:k + 512]):]
    return np.vstack([out * env, np.roll(out, 240) * env]) * 0.5
def scrub_snd(d):
    t = tt(d)
    v = np.sin(np.pi * np.clip(t / d, 0, 1))
    am = 0.5 + 0.5 * np.sign(np.sin(2 * np.pi * (18 + 60 * v) * t))
    x = bp(rng.standard_normal(len(t)), 400, 5000) * am * v ** 1.2
    tone = np.sin(2 * np.pi * np.cumsum(200 + 900 * v) / SR) * v * 0.15
    return (x * 0.45 + tone) * 0.6
def riser(d):
    t = tt(d)
    p = t / d
    n = hp(rng.standard_normal(len(t)), 900) * p ** 2.2 * 0.35
    tone = np.sin(2 * np.pi * np.cumsum(200 + 1400 * p ** 2) / SR) * p ** 2 * 0.12
    return np.vstack([n + tone, np.roll(n, 300) + tone])
def boom():
    t = tt(2.2)
    f = 34 + 50 * np.exp(-t / 0.15)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.7) * np.minimum(1, t / 0.004)
    return np.tanh(1.5 * x) * 0.8 + lp(rng.standard_normal(len(t)), 400) * np.exp(-t / 0.3) * 0.12
def lock_snd():
    latch = np.pad(noise_burst(0.03, 2500, 9000, 0.004), (int(0.03 * SR), 0))
    out = np.zeros(int(0.07 * SR)); c = click_snd()
    out[:len(c)] += c * 1.4; out[:len(latch)] += latch[:len(out)] * 0.8
    return out
def shimmer(d=0.8):
    out = np.zeros((2, int(d * SR) + int(1.5 * SR)))
    for i, m in enumerate((86, 90, 93, 97, 98, 102)):
        b = bell(m, 1.4, 0.8, 4.0, 0.35) * 0.35
        o = int(i * d / 6 * SR)
        out[i % 2, o:o + len(b)] += b
    return out

for c in cues:
    ty, at = c['type'], c['t']
    if ty == 'key': sfx.add(key_snd(c.get('ch', 'a')), at, 0.28, pan=rng.uniform(-0.15, 0.15))
    elif ty == 'key2': sfx.add(key_snd('a') * 1.6 + lp(key_snd(' '), 1200), at, 0.45)
    elif ty == 'click': sfx.add(click_snd(), at, 0.45, pan=0.1)
    elif ty == 'pop': sfx.add(pop_snd(c.get('pitch', 1)), at, 0.5 * c.get('gain', 1), pan=-0.1)
    elif ty in ('tick', 'roll'): sfx.add(tick_snd(1.0 if ty == 'tick' else 0.8), at, 0.3 * c.get('gain', 1))
    elif ty == 'tickSoft': sfx.add(tick_snd(1.2), at, 0.12)
    elif ty == 'whoosh': sfx.add(whoosh_snd(c.get('len', 0.6)), at - c.get('len', 0.6) * 0.35, 0.55 * c.get('gain', 0.5))
    elif ty == 'scrub': sfx.add(scrub_snd(c['len'] + 0.06), at, 0.35, pan=rng.uniform(-0.3, 0.3))
    elif ty == 'riser': sfx.add(riser(c['len']), at, 0.7)
    elif ty == 'boom': sfx.add(boom(), at, 0.9)
    elif ty == 'chime':
        for i, m in enumerate((74, 78, 81, 85)): sfx.add(bell(m, 2.6, 1.8, 3.5, 1.0), at + i * 0.015, 0.16, pan=-0.3 + i * 0.2)
    elif ty == 'ring': sfx.add(bell(93, 1.0, 0.5, 2.0, 0.25), at, 0.05)
    elif ty == 'select': sfx.add(whoosh_snd(0.18), at - 0.05, 0.15)
    elif ty == 'delete': sfx.add(lp(click_snd(), 1500) * 1.5, at, 0.4)
    elif ty == 'send': sfx.add(whoosh_snd(0.35), at - 0.05, 0.3); sfx.add(pop_snd(1.3), at, 0.3)
    elif ty == 'shimmer': sfx.add(shimmer(0.7), at, 0.5)
    elif ty == 'lock': sfx.add(lock_snd(), at, 0.8)
    elif ty == 'final': sfx.add(boom(), at, 0.7); sfx.add(whoosh_snd(0.5), at - 0.4, 0.35)
# The circle wipes.
for at in (21.15, 24.9, 27.3): sfx.add(whoosh_snd(0.5), at - 0.05, 0.45)

# ---------------------------------------------------------------- mix
# The kick pumps the pad and arpeggio a little.
kicks = [beat(k) for k in range(60) if 10.4 <= beat(k) < 27.3]
duck = np.ones(N)
for k in kicks:
    i = int(k * SR); t = tt(0.3)
    duck[i:i + len(t)] = np.minimum(duck[i:i + len(t)], 1 - 0.28 * np.exp(-t / 0.09))
def peak_eq(x, f0, gain_db, q=0.9):
    A = 10 ** (gain_db / 40); w = 2 * np.pi * f0 / SR; al = np.sin(w) / (2 * q)
    b = [1 + al * A, -2 * np.cos(w), 1 - al * A]; a = [1 + al / A, -2 * np.cos(w), 1 - al / A]
    return signal.lfilter(b, a, x)
m = music.x * duck
m = np.vstack([peak_eq(peak_eq(m[c], 260, -4.0, 0.8), 3200, 1.5, 0.7) for c in range(2)])
# The breath before the end card: music drops out from 27.3 to 27.6.
g = np.ones(N); t = np.arange(N) / SR
g = np.where((t > 27.28) & (t < 27.6), np.clip(1 - (t - 27.28) / 0.05, 0.05, 1), g)
m = m * g
m = m + reverb(m) * 0.45
s = sfx.x + reverb(sfx.x) * 0.25
mix = m * 0.9 + s * 0.85
fade = np.clip((DUR - t) / 0.35, 0, 1) * np.clip(t / 0.05, 0, 1)
mix *= fade
pk = np.abs(mix).max()
mix = np.tanh(mix / pk * 1.4) / np.tanh(1.4) * 0.89

def write(path, x):
    x = np.clip(x, -1, 1)
    data = (x.T * (2 ** 23 - 1)).astype('<i4')
    b = np.zeros((data.shape[0], 2, 3), dtype=np.uint8)
    for ch in range(2):
        v = data[:, ch].astype(np.int64) & 0xFFFFFF
        b[:, ch, 0] = v & 0xFF; b[:, ch, 1] = (v >> 8) & 0xFF; b[:, ch, 2] = (v >> 16) & 0xFF
    with wave.open(path, 'wb') as w:
        w.setnchannels(2); w.setsampwidth(3); w.setframerate(SR); w.writeframes(b.tobytes())
write(f'{here}/music.wav', m / max(1e-9, np.abs(m).max()) * 0.8)
write(f'{here}/sfx.wav', s / max(1e-9, np.abs(s).max()) * 0.8)
write(f'{here}/mix.wav', mix)
print('wrote mix.wav, peak', np.abs(mix).max())
