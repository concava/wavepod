"""Sparse felt-key / ambient score, timed narration and a quiet final mix.
No third-party recordings or samples. Python + NumPy + SciPy + SoundFile; FFmpeg.
"""
from pathlib import Path
import numpy as np
from scipy.signal import resample_poly, butter, sosfilt
import soundfile as sf
import subprocess,json,re,math
ROOT=Path(__file__).resolve().parent; SR=48000; N=20*SR
rng=np.random.default_rng(20261022)
music=np.zeros((N,2)); voice=np.zeros((N,2))
def hz(n):return 440*2**((n-69)/12)
def place(bus,s,start,gain,pan=0):
 i=round(start*SR); count=min(len(s),N-i)
 if count>0:bus[i:i+count]+=s[:count,None]*gain*np.array([np.cos((pan+1)*np.pi/4),np.sin((pan+1)*np.pi/4)])
def felt(note,length=4):
 t=np.arange(round(length*SR))/SR; f=hz(note); s=np.zeros(len(t))
 # Softly struck, slightly inharmonic strings with fast-decaying upper partials.
 for k,amp in enumerate([1,.29,.105,.041,.014],1):
  decay=1.25+k*.48
  for cents in [-.0006,.0006]:
   s+=amp*.5*np.sin(2*np.pi*f*k*(1+cents+.00012*k*k)*t)*np.exp(-t*decay)
 s*=(1-np.exp(-t*210))*np.minimum(1,(length-t)/.4)
 return s

def pad(notes,length=7):
 t=np.arange(round(length*SR))/SR; s=np.zeros(len(t))
 for j,n in enumerate(notes):
  s+=(np.sin(2*np.pi*hz(n)*t+.4*j)+.13*np.sin(2*np.pi*hz(n)*2.0003*t))/len(notes)
 env=np.sin(np.pi*np.minimum(t/1.2,1)/2)**2*np.sin(np.pi*np.minimum((length-t)/2.4,1)/2)**2
 return s*env
# 96 BPM, four-bar harmonic arc. Space between notes lets the guide voice lead.
chords=[[50,57,61,64,69],[47,54,57,61,66],[43,50,57,59,66],[50,57,61,64,69]]
for bar,notes in enumerate(chords):
 start=bar*5.0
 place(music,pad(notes[1:]),start,.032,(-.2 if bar%2 else .2))
 for j,n in enumerate(notes):place(music,felt(n,5),start+.15+j*.017,.09 if j else .11,(j-2)*.19)
 for beat,degree,octave,gain in [(2.5,3,0,.055),(3.75,4,0,.039),(4.375,2,12,.025)]:
  if bar==3 and beat>3:continue
  place(music,felt(notes[degree]+octave),start+beat,gain,(-.3 if degree%2 else .3))
# Small high note answers the brand landing; no big impact or percussion.
place(music,felt(78,3),17.45,.027,.25)
# Diffuse, dark room around keys rather than bright arpeggios or whooshes.
dry=music.copy()
for delay,level in [(.071,.14),(.119,.11),(.193,.09),(.313,.065),(.491,.045),(.719,.025)]:
 d=int(delay*SR);music[d:]+=dry[:-d,::-1]*level
music=sosfilt(butter(2,4400,fs=SR,output='sos'),music,axis=0)
clock=np.arange(N)/SR
music*=np.minimum(1,clock/.30)[:,None]*np.minimum(1,np.maximum(0,(20-clock)/1.1))[:,None]
sf.write(ROOT/'music-premaster.wav',music,SR,subtype='PCM_24')

def normalize(src,dst,level,peak=-3):
 cmd=['ffmpeg','-hide_banner','-nostats','-i',str(src),'-af',f'loudnorm=I={level}:TP={peak}:LRA=8:print_format=json','-f','null','-']
 r=subprocess.run(cmd,capture_output=True,text=True,check=True)
 info=json.loads(re.search(r'\{\s*"input_i".*?\}',r.stderr,re.S).group())
 filt=f"loudnorm=I={level}:TP={peak}:LRA=8:measured_I={info['input_i']}:measured_TP={info['input_tp']}:measured_LRA={info['input_lra']}:measured_thresh={info['input_thresh']}:offset={info['target_offset']}:linear=true"
 subprocess.run(['ffmpeg','-v','error','-y','-i',str(src),'-af',filt,'-ar',str(SR),'-c:a','pcm_s24le',str(dst)],check=True)
 return info
normalize(ROOT/'music-premaster.wav',ROOT/'wavepod-soft-piano.wav',-32,-6)
music,_=sf.read(ROOT/'wavepod-soft-piano.wav')
cues=json.loads((ROOT/'narration-cues.json').read_text())
duck=np.ones(N)
for cue in cues:
 samples,rate=sf.read(ROOT/cue['file']);samples=resample_poly(samples,SR,rate)
 # Equalize phrase RMS before gentle full-track mastering.
 active=samples[np.abs(samples)>.008];rms=np.sqrt(np.mean(active**2))
 samples*=.1/max(rms,.01)
 i=int(cue['start']*SR);n=min(len(samples),N-i)
 voice[i:i+n]=samples[:n,None]
 # Smooth 5 dB duck, beginning before the consonant and releasing after the phrase.
 start=cue['start'];end=cue['end'];attack=np.clip((clock-(start-.12))/.12,0,1);release=np.clip(((end+.28)-clock)/.28,0,1)
 env=np.minimum(attack,release);env=env*env*(3-2*env)
 duck=np.minimum(duck,1-env*(1-10**(-5/20)))
voice=sosfilt(butter(2,80,btype='highpass',fs=SR,output='sos'),voice,axis=0)
sf.write(ROOT/'voice-premaster.wav',voice,SR,subtype='PCM_24')
normalize(ROOT/'voice-premaster.wav',ROOT/'wavepod-voiceover.wav',-20,-3)
voice,_=sf.read(ROOT/'wavepod-voiceover.wav')
music*=duck[:,None]
sf.write(ROOT/'wavepod-music-ducked.wav',music,SR,subtype='PCM_24')
mix=voice+music
sf.write(ROOT/'mix-premaster.wav',mix,SR,subtype='PCM_24')
normalize(ROOT/'mix-premaster.wav',ROOT/'wavepod-narrated-mix.wav',-20,-3)
info=normalize(ROOT/'wavepod-narrated-mix.wav',ROOT/'qa-normalized.wav',-20,-3)
(ROOT/'qa-normalized.wav').unlink()
(ROOT/'audio-stats.json').write_text(json.dumps({'duration_seconds':20,'sample_rate':SR,'channels':2,'voice':'Kokoro v1.0 af_heart (stock synthetic voice)','score':'Original sparse felt-key and ambient composition, 96 BPM','music_base_lufs':-32,'music_duck_db':5,'mix_integrated_lufs':float(info['input_i']),'mix_true_peak_dbtp':float(info['input_tp']),'mix_loudness_range_lu':float(info['input_lra']),'previous_mix_lufs':-17.01},indent=2)+'\n')
# Optional accessible captions, kept separate so app typography remains unobscured.
def stamp(t):
 ms=round(t*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
(ROOT/'narration.srt').write_text('\n\n'.join(f"{i+1}\n{stamp(c['start'])} --> {stamp(c['end'])}\n{c['text']}" for i,c in enumerate(cues))+'\n')
print(json.dumps(info),flush=True)
