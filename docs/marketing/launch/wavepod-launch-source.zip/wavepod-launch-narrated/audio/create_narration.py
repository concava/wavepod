"""Render locally using Kokoro's stock af_heart voice; no voice cloning.
Usage: python create_narration.py --model-dir /path/to/kokoro-files
Requires kokoro-onnx and soundfile. Model files are not bundled.
"""
from pathlib import Path
import argparse,json
import numpy as np
import soundfile as sf
from kokoro_onnx import Kokoro
p=argparse.ArgumentParser();p.add_argument('--model-dir',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parent
engine=Kokoro(str(a.model_dir/'kokoro-v1.0.onnx'),str(a.model_dir/'voices-v1.0.bin'))
cues=[
 (.55,3.05,'Your podcasts. Now readable.'),
 (3.45,5.35,'Paste a link.'),
 (5.92,8.30,'Get the story, at a glance.'),
 (8.70,10.50,'Ask a question.'),
 (11.05,13.52,'Find answers in the episode.'),
 (13.95,16.65,'Read along, or keep listening.'),
 (17.30,19.75,'Wavepod. Free for Mac.'),
]
manifest=[]
for i,(start,deadline,text) in enumerate(cues):
 samples,sr=engine.create(text.replace('Wavepod','Wave pod'),voice='af_heart',speed=0.88,lang='en-us')
 active=np.where(np.abs(samples)>.004)[0]
 if len(active):samples=samples[max(0,active[0]-int(.045*sr)):min(len(samples),active[-1]+int(.12*sr))]
 duration=len(samples)/sr
 if duration>deadline-start:
  # A small tempo correction keeps consonants intact and avoids racing to the next shot.
  import subprocess
  sf.write(root/'tempo-input.wav',samples,sr)
  ratio=duration/(deadline-start)
  subprocess.run(['ffmpeg','-v','error','-y','-i',str(root/'tempo-input.wav'),'-af',f'atempo={ratio}',str(root/'tempo-output.wav')],check=True)
  samples,sr=sf.read(root/'tempo-output.wav');duration=len(samples)/sr
 name=f'voice-{i+1:02d}.wav';sf.write(root/name,samples,sr,subtype='PCM_24')
 manifest.append({'start':start,'end':round(start+duration,3),'text':text,'file':name,'voice':'af_heart','engine':'Kokoro v1.0'})
 print(text,round(duration,3),'seconds',flush=True)
(root/'narration-cues.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'narration.txt').write_text('\n'.join(x['text'] for x in manifest)+'\n')
