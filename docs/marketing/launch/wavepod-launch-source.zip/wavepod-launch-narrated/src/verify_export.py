from pathlib import Path
import json,subprocess,re,hashlib
root=Path(__file__).resolve().parents[1]
film=root/'exports/wavepod-launch-narrated-20s.mp4'
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration,size:stream=index,codec_name,width,height,r_frame_rate,nb_frames,duration,pix_fmt,color_range,color_space,color_transfer,color_primaries,sample_rate,channels','-of','json',str(film)]))
v=probe['streams'][0];a=probe['streams'][1]
assert (v['width'],v['height'],v['r_frame_rate'],v['nb_frames'])==(1920,1080,'60/1','1200')
assert float(probe['format']['duration'])==20 and float(a['duration'])==20
r=subprocess.run(['ffmpeg','-v','error','-i',str(film),'-f','null','-'],capture_output=True,text=True,check=True)
assert not r.stderr,r.stderr
r=subprocess.run(['ffmpeg','-hide_banner','-nostats','-i',str(film),'-vn','-af','loudnorm=I=-20:TP=-3:LRA=8:print_format=json','-f','null','-'],capture_output=True,text=True,check=True)
stats=json.loads(re.search(r'\{\s*"input_i".*?\}',r.stderr,re.S).group())
assert float(stats['input_tp'])<0
subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(film),'-vf','fps=2,scale=384:216,tile=5x8:padding=6:margin=6:color=white','-frames:v','1',str(root/'preview/final-encoded-contact-sheet.jpg')],check=True)
verify={'export':str(film.relative_to(root)),'sha256':hashlib.sha256(film.read_bytes()).hexdigest(),'probe':probe,'full_decode_passed':True,'audio':{'integrated_lufs':float(stats['input_i']),'true_peak_dbtp':float(stats['input_tp']),'loudness_range_lu':float(stats['input_lra'])},'changes':['Removed two misplaced emphasis rectangles','New York semibold headings; SF Pro supporting text, matching app Theme.swift','Stock synthetic guide voice, seven scene-timed phrases','Original sparse piano/ambient score, ducked under narration','Mix target -20 LUFS versus previous -17 LUFS']}
(root/'verification.json').write_text(json.dumps(verify,indent=2)+'\n')
print(json.dumps({'frames':v['nb_frames'],'duration':probe['format']['duration'],'audio':verify['audio'],'decode':'passed'}))
