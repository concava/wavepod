// Wavepod: a 20-second product film. Deterministic Skia animation, 60 fps.
// All product textures come from the app; motion and type are authored here.
const fs = require('node:fs');
const path = require('node:path');
const {spawn} = require('node:child_process');
const {once} = require('node:events');
const {createCanvas, loadImage, GlobalFonts} = require('@napi-rs/canvas');
const ROOT=path.resolve(__dirname,'..');
const OUT=path.join(ROOT,'exports');
const PREVIEW=path.join(ROOT,'preview');
fs.mkdirSync(OUT,{recursive:true}); fs.mkdirSync(PREVIEW,{recursive:true});
GlobalFonts.registerFromPath('/System/Library/Fonts/SFNS.ttf','SF Pro');
GlobalFonts.registerFromPath('/System/Library/Fonts/NewYork.ttf','New York');
const W=1920,H=1080,FPS=60,DURATION=20;
const C={paper:'#F4F1EA',ink:'#1C1B19',teal:'#0F5E63',deep:'#103F43',mint:'#DCEAE3',white:'#FFFFFF',muted:'#6B665E',gold:'#C99958'};
const assets={};
const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const lerp=(a,b,t)=>a+(b-a)*t;
const out=x=>1-Math.pow(1-clamp(x),5);
const into=x=>Math.pow(clamp(x),4);
const smooth=x=>{x=clamp(x);return x*x*(3-2*x);};
const ease=x=>{x=clamp(x);return x<.5?16*x*x*x*x*x:1-Math.pow(-2*x+2,5)/2;};
const phase=(t,a,b,fn=out)=>fn((t-a)/(b-a));
const mixBox=(a,b,p)=>a.map((x,i)=>lerp(x,b[i],p));
const main=createCanvas(W,H); const ctx=main.getContext('2d');
const bg=createCanvas(W,H); const bgc=bg.getContext('2d');
bgc.fillStyle=C.paper;bgc.fillRect(0,0,W,H);
let g=bgc.createLinearGradient(0,0,1500,1080);g.addColorStop(0,'#FCFBF7');g.addColorStop(.55,'#F4F1EA');g.addColorStop(1,'#D9E7DF');bgc.fillStyle=g;bgc.fillRect(0,0,W,H);

function round(x,y,w,h,r=24){ctx.beginPath();ctx.roundRect(x,y,w,h,r);}
function shadow(alpha=.16,blur=38,dy=20){ctx.shadowColor=`rgba(23,54,50,${alpha})`;ctx.shadowBlur=blur;ctx.shadowOffsetY=dy;ctx.shadowOffsetX=0;}
function noShadow(){ctx.shadowColor='transparent';ctx.shadowBlur=0;ctx.shadowOffsetY=0;ctx.shadowOffsetX=0;}
function txt(text,x,y,size=80,color=C.ink,align='left',family='SF Pro',weight=500){ctx.font=`${weight} ${size}px "${family}"`;ctx.fillStyle=color;ctx.textAlign=align;ctx.textBaseline='alphabetic';ctx.fillText(text,x,y);}
function maskText(text,x,y,size,p,{color=C.ink,align='left',family='New York',weight=600,direction=1}={}){
  p=clamp(p);if(p<=0)return;ctx.save();ctx.beginPath();ctx.rect(0,y-size*1.12,W,size*1.42);ctx.clip();
  ctx.globalAlpha*=clamp(p*3);txt(text,x,y+(1-out(p))*size*direction,size,color,align,family,weight);ctx.restore();
}
function wave(x,y,w,h,color=C.teal,width=6,progress=1,phaseShift=0){
  ctx.save();ctx.strokeStyle=color;ctx.lineWidth=width;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();
  const count=Math.floor(180*clamp(progress));
  for(let i=0;i<=count;i++){let p=i/180;let yy=y+h/2-Math.sin(p*Math.PI*7+phaseShift)*Math.max(0,1-p*1.25)*h*.28;i?ctx.lineTo(x+p*w,yy):ctx.moveTo(x,yy);}
  ctx.stroke();ctx.restore();
}
function icon(kind,x,y,size,color=C.teal){
  ctx.save();ctx.translate(x,y);ctx.strokeStyle=color;ctx.fillStyle=color;ctx.lineCap='round';ctx.lineJoin='round';ctx.lineWidth=size*.055;
  if(kind==='link'){
    ctx.rotate(-Math.PI/4);for(const dy of [-.18,.18]){ctx.beginPath();ctx.roundRect(-size*.19,dy*size-size*.25,size*.38,size*.5,size*.17);ctx.stroke();}
    ctx.beginPath();ctx.moveTo(0,-size*.15);ctx.lineTo(0,size*.15);ctx.stroke();
  }else if(kind==='play'){ctx.beginPath();ctx.moveTo(-size*.20,-size*.32);ctx.lineTo(size*.32,0);ctx.lineTo(-size*.20,size*.32);ctx.closePath();ctx.fill();
  }else if(kind==='quote'){for(const dx of [-.21,.15]){ctx.beginPath();ctx.roundRect(dx*size,-size*.25,size*.25,size*.31,size*.04);ctx.fill();ctx.beginPath();ctx.moveTo((dx+.23)*size,.01*size);ctx.quadraticCurveTo((dx+.2)*size,.22*size,dx*size,.25*size);ctx.stroke();}
  }else if(kind==='arrow'){ctx.beginPath();ctx.moveTo(0,size*.28);ctx.lineTo(0,-size*.26);ctx.moveTo(-size*.23,-size*.04);ctx.lineTo(0,-size*.27);ctx.lineTo(size*.23,-size*.04);ctx.stroke();
  }else if(kind==='search'){ctx.beginPath();ctx.arc(-size*.07,-size*.07,size*.22,0,Math.PI*2);ctx.stroke();ctx.beginPath();ctx.moveTo(size*.10,size*.10);ctx.lineTo(size*.29,size*.29);ctx.stroke();
  }else if(kind==='speaker'){ctx.beginPath();ctx.moveTo(-size*.35,-size*.12);ctx.lineTo(-size*.15,-size*.12);ctx.lineTo(size*.06,-size*.31);ctx.lineTo(size*.06,size*.31);ctx.lineTo(-size*.15,size*.12);ctx.lineTo(-size*.35,size*.12);ctx.closePath();ctx.stroke();for(const rad of [.25,.4]){ctx.beginPath();ctx.arc(size*.07,0,size*rad,-.8,.8);ctx.stroke();}
  }else if(kind==='lock'){ctx.beginPath();ctx.roundRect(-size*.28,-size*.05,size*.56,size*.44,size*.08);ctx.stroke();ctx.beginPath();ctx.arc(0,-size*.12,size*.18,Math.PI,0);ctx.lineTo(size*.18,-size*.02);ctx.moveTo(-size*.18,-size*.12);ctx.lineTo(-size*.18,-size*.02);ctx.stroke();
  }else if(kind==='lines'){for(let i=0;i<4;i++){ctx.beginPath();ctx.moveTo(-size*.35,-size*.27+i*size*.18);ctx.lineTo(size*(i===3?.12:.35),-size*.27+i*size*.18);ctx.stroke();}}
  ctx.restore();
}
function background(t,dark=false){
  ctx.globalAlpha=1;ctx.setTransform(1,0,0,1,0,0);noShadow();
  if(dark){ctx.fillStyle=C.deep;ctx.fillRect(0,0,W,H);const glow=ctx.createRadialGradient(650+Math.sin(t)*70,400,30,1000,500,1200);glow.addColorStop(0,'#175D60');glow.addColorStop(1,C.deep);ctx.fillStyle=glow;ctx.fillRect(0,0,W,H);}
  else ctx.drawImage(bg,0,0);
  // Barely perceptible ambient curves give camera moves a stationary depth reference.
  ctx.save();ctx.globalAlpha=dark?.05:.045;ctx.strokeStyle=dark?C.mint:C.teal;ctx.lineWidth=1.5;
  for(let i=0;i<4;i++){ctx.beginPath();let yy=900+i*95+Math.sin(t*.4+i*.6)*25;ctx.moveTo(-100,yy);ctx.bezierCurveTo(500,yy-190,1300,yy+150,2070,yy-80);ctx.stroke();}ctx.restore();
}
function card(image,box,{radius=28,alpha=1,rotation=0,tilt=0,shadowAlpha=.16,blur=35,fill=C.white,fadeBottom=false}={}){
  if(alpha<=0)return;const[x,y,w,h]=box;ctx.save();ctx.globalAlpha*=alpha;ctx.translate(x+w/2,y+h/2);ctx.rotate(rotation);ctx.transform(1,tilt,0,1,0,0);
  shadow(shadowAlpha,blur,20);round(-w/2,-h/2,w,h,radius);ctx.fillStyle=fill;ctx.fill();noShadow();ctx.save();round(-w/2,-h/2,w,h,radius);ctx.clip();if(image)ctx.drawImage(image,-w/2,-h/2,w,h);
  if(fadeBottom){const gr=ctx.createLinearGradient(0,h/2-60,0,h/2);gr.addColorStop(0,'rgba(255,255,255,0)');gr.addColorStop(1,'#FFFFFF');ctx.fillStyle=gr;ctx.fillRect(-w/2,h/2-60,w,60);}
  ctx.restore();ctx.strokeStyle='rgba(20,65,62,.10)';ctx.lineWidth=1;round(-w/2,-h/2,w,h,radius);ctx.stroke();ctx.restore();
}
// Perspective is a continuous strip projection; the surface keeps its identity through a Y flip.
function perspectiveCard(image,box,angle,alpha=1){
  const[x,y,w,h]=box;ctx.save();ctx.globalAlpha*=alpha;let ca=Math.cos(angle),sa=Math.sin(angle);let cx=x+w/2,cy=y+h/2;
  if(Math.abs(ca)<.03){ctx.fillStyle=C.teal;ctx.fillRect(cx-2,y,4,h);ctx.restore();return;}
  for(let i=0;i<80;i++){let u0=i/80,u1=(i+1)/80;let p0=(u0-.5)*w,p1=(u1-.5)*w;let z0=1+(p0*sa)/2100,z1=1+(p1*sa)/2100;let xx0=cx+p0*ca/z0,xx1=cx+p1*ca/z1;let hh=h/((z0+z1)/2);ctx.drawImage(image,u0*image.width,0,image.width/80+.8,image.height,Math.min(xx0,xx1),cy-hh/2,Math.abs(xx1-xx0)+1,hh);}
  ctx.restore();
}
function pill(box,content,{alpha=1,typed=1,send=true,fill='#EEECE4',fontSize=42,press=0}={}){
  const[x,y,w,h]=box;ctx.save();ctx.globalAlpha*=alpha;card(null,box,{radius:h/2,fill,shadowAlpha:.12,blur:30});
  icon('search',x+70,y+h/2,48,C.teal);ctx.save();ctx.beginPath();ctx.rect(x+120,y+5,w-240,h-10);ctx.clip();
  const part=content.slice(0,Math.floor(content.length*clamp(typed)));txt(part,x+125,y+h/2+fontSize*.35,fontSize,C.ink,'left','SF Pro',400);
  if(typed<1){ctx.font=`400 ${fontSize}px "SF Pro"`;ctx.fillStyle=C.teal;ctx.fillRect(x+129+ctx.measureText(part).width,y+h/2-fontSize*.4,2,fontSize*.9);}
  ctx.restore();
  if(send){ctx.save();ctx.translate(x+w-65,y+h/2);let s=1-press*.13;ctx.scale(s,s);ctx.fillStyle=C.teal;ctx.beginPath();ctx.arc(0,0,42,0,Math.PI*2);ctx.fill();icon('arrow',0,0,48,C.white);ctx.restore();}
  ctx.restore();
}
function cursor(x,y,scale=1,alpha=1){ctx.save();ctx.globalAlpha*=alpha;ctx.translate(x,y);ctx.scale(scale,scale);shadow(.2,8,3);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(7,34);ctx.lineTo(16,23);ctx.lineTo(30,21);ctx.closePath();ctx.fillStyle=C.ink;ctx.fill();noShadow();ctx.strokeStyle='white';ctx.lineWidth=2.5;ctx.stroke();ctx.restore();}

function opening(t){
  background(t);
  // One mark becomes a world of podcast objects, then compresses into the input.
  if(t<1.65){
    const pull=phase(t,.32,1.03,ease),push=phase(t,1.20,1.65,into);
    const scale=lerp(1.7,.63,pull)*(1+push*5.8);ctx.save();ctx.translate(960,515);ctx.scale(scale,scale);
    const a=phase(t,.45,.83,out)*(1-push);
    for(let row=-2;row<=2;row++)for(let col=-3;col<=3;col++){
      if(row===0&&col===0)continue;let delay=((col+3)+(row+2)*.6)*.018;let p=phase(t,.45+delay,.85+delay,out);if(p<=0)continue;
      let xx=col*330,yy=row*240;ctx.save();ctx.globalAlpha=a*p;ctx.translate(xx,yy+(1-p)*70);ctx.rotate((col-row)*.025);
      const kind=['wave','quote','lines','play','artwork'][((row+2)*7+col+3)%5];
      shadow(.12,25,12);round(-90,-65,180,130,29);ctx.fillStyle=((row+col)%3===0)?'#E2ECE6':'#FFFFFF';ctx.fill();noShadow();
      if(kind==='wave')wave(-64,-35,128,70,C.teal,5);else if(kind==='artwork') {ctx.save();round(-48,-48,96,96,14);ctx.clip();ctx.drawImage(assets.artwork,-48,-48,96,96);ctx.restore();}else icon(kind,0,0,70,C.teal);ctx.restore();
    }
    shadow(.15,50,22);round(-135,-130,270,260,60);ctx.fillStyle=C.white;ctx.fill();noShadow();wave(-92,-70,184,140,C.teal,10,phase(t,0,.35,out));ctx.restore();
    if(t<.5){ctx.save();ctx.globalAlpha=phase(t,.06,.25,out)*(1-phase(t,.35,.5,into));txt('Wavepod',960,866,44,C.ink,'center','New York',600);ctx.restore();}
  }else{
    const enter=phase(t,1.65,2.00,out),exit=phase(t,2.70,3.25,ease);
    ctx.save();ctx.globalAlpha=1-exit;maskText('Your podcasts.',960,430-exit*80,146,enter,{align:'center',weight:600});ctx.restore();
    ctx.save();ctx.globalAlpha=1-exit;maskText('Now readable.',960,595,146,phase(t,1.91,2.26,out),{align:'center',color:C.teal,weight:600});ctx.restore();
    // The underline becomes the input's edge; silhouette and position carry across the cut.
    let box=mixBox([450,685,1020,10],[300,440,1320,160],exit);
    ctx.save();ctx.globalAlpha=clamp(phase(t,2.10,2.36,out)+exit);shadow(.14*exit,30,16);round(...box,lerp(5,80,exit));ctx.fillStyle=exit>.05?C.white:C.teal;ctx.fill();noShadow();ctx.restore();
    if(exit>0){ctx.save();ctx.globalAlpha=exit;icon('link',370,520,52);ctx.restore();}
  }
}

const appBox=[240,170,1440,888.75];
function linkToApp(t){
  const u=t-3.25;background(t);
  const cap=1-phase(u,1.1,1.55,into);
  ctx.save();ctx.globalAlpha=cap;maskText('Start with a link.',960,272,90,phase(u,0,.38,out),{align:'center',weight:600});ctx.restore();
  if(u<1.25){
    const box=[300,440,1320,160];card(null,box,{radius:80,fill:C.white});icon('link',370,520,52);
    ctx.save();ctx.globalAlpha=phase(u,.10,.45,out);txt('Paste a podcast link',440,537,43,C.muted,'left','SF Pro',400);ctx.restore();
    const names=['Spotify','Apple Podcasts','YouTube'];
    names.forEach((s,i)=>{const p=phase(u,.3+i*.08,.64+i*.08,out);if(!p)return;ctx.save();ctx.globalAlpha=p*(1-phase(u,.8,1.25,into));let x=960+(i-1)*320;round(x-139,700+(1-p)*55,278,74,37);ctx.strokeStyle='rgba(15,94,99,.20)';ctx.lineWidth=1.4;ctx.stroke();txt(s,x,748+(1-p)*55,30,C.teal,'center','SF Pro',500);ctx.restore();});
  }else{
    const p=phase(u,1.25,1.93,ease);
    let box=mixBox([300,440,1320,160],appBox,p);
    // Flip the input edge-on, then unfold the real app on the same center.
    if(p<.48){let angle=lerp(0,Math.PI/2,p/.48);const surface=createCanvas(1320,160);const sc=surface.getContext('2d');sc.fillStyle='#FFFFFF';sc.beginPath();sc.roundRect(0,0,1320,160,80);sc.fill();sc.font='400 43px "SF Pro"';sc.fillStyle=C.muted;sc.fillText('Paste a podcast link',140,97);perspectiveCard(surface,box,angle);}
    else{let a=lerp(-Math.PI/2,0,out((p-.48)/.52));if(p>.94)card(assets['app-window'],box,{radius:24});else perspectiveCard(assets['app-window'],box,a);}
  }
}

function summaryScene(t){
  const u=t-5.75;background(t);const lift=phase(u,0,.64,ease),bridge=phase(u,2.32,2.75,ease);
  let backBox=mixBox(appBox,[520,180,1540,950],lift);
  ctx.save();ctx.globalAlpha=(1-lift*.84)*(1-bridge);if(lift>.4)ctx.filter='blur(2px)';card(assets['app-window'],backBox,{rotation:-.035*lift,shadowAlpha:.12});ctx.filter='none';ctx.restore();
  const native=[appBox[0]+490/2560*appBox[2],appBox[1]+805/1580*appBox[3],980/2560*appBox[2],350/1580*appBox[3]];
  const hero=[810,340,1000,357.14];let box=mixBox(native,hero,lift);box=mixBox(box,[210,470,1500,150],bridge);
  ctx.save();ctx.globalAlpha=1-bridge;
  maskText('The whole',135,413,102,phase(u,.22,.65,out),{weight:600});
  maskText('story.',135,533,126,phase(u,.31,.74,out),{weight:600,color:C.teal});
  maskText('At a glance.',140,640,45,phase(u,.49,.92,out),{family:'SF Pro',weight:400});
  ctx.restore();
  // A second actual pane counter-moves behind the selected summary.
  let tp=phase(u,1.03,1.55,out)*(1-bridge);if(tp>0){card(assets.transcript,[1040,655+(1-tp)*60,770,400.55],{alpha:tp*.40,rotation:.035,shadowAlpha:.10,fadeBottom:true});}
  card(bridge>.75?null:assets.summary,box,{radius:lerp(26,75,bridge),alpha:1,fill:bridge>.75?'#EEECE4':C.white,rotation:0});
  if(bridge>0){ctx.save();ctx.globalAlpha=bridge;icon('search',box[0]+70,box[1]+box[3]/2,48);ctx.restore();}
}

const QUESTION='Why did the Pixar deal matter so much for Disney?';
function askScene(t){
  const u=t-8.5;background(t);const p=phase(u,0,.35,out);
  maskText('Ask the episode.',960,290,100,p,{align:'center',weight:600});
  const typed=phase(u,.30,1.35,x=>clamp(x));
  const press=Math.sin(Math.PI*clamp((u-1.91)/.27));
  pill([210,470,1500,150],QUESTION,{typed,fontSize:39,press});
  let cp=phase(u,1.43,1.87,out);if(cp>0){cursor(lerp(1570,1645,cp),lerp(735,545,cp),1.2,cp);}
  if(u>1.93){let q=clamp((u-1.93)/.32);ctx.save();ctx.strokeStyle=`rgba(15,94,99,${(1-q)*.32})`;ctx.lineWidth=3;ctx.beginPath();ctx.arc(1645,545,42+q*55,0,Math.PI*2);ctx.stroke();ctx.restore();}
  const chips=['Summaries','Quotes','Answers'];chips.forEach((s,i)=>{let q=phase(u,.2+i*.09,.65+i*.09,out);ctx.save();ctx.globalAlpha=q*.6;txt(s,960+(i-1)*250,755+(1-q)*30,28,C.teal,'center','SF Pro',500);ctx.restore();});
}

const answerBox=[220,255,1480,679];
function answerScene(t){
  const u=t-10.75;background(t);let p=phase(u,0,.60,ease),exit=phase(u,2.55,3,ease);
  let box=mixBox([210,470,1500,150],answerBox,p);
  if(exit>0){
    box=mixBox(answerBox,[880,160,924,824],exit);
    perspectiveCard(assets.answer,box,exit*Math.PI/2);
    ctx.save();ctx.globalAlpha=1-exit;maskText('Answers you can explore.',960,155-exit*70,62,1,{align:'center',weight:600});ctx.restore();
    return;
  }
  card(null,box,{radius:lerp(75,32,p),fill:C.white,shadowAlpha:.20});
  ctx.save();round(...box,lerp(75,32,p));ctx.clip();ctx.globalAlpha=phase(u,.16,.52,out);ctx.drawImage(assets.answer,box[0],box[1]+(1-p)*110,box[2],box[3]);ctx.restore();
  if(p<1){ctx.save();ctx.globalAlpha=1-phase(u,.05,.30,out);pill([210,470,1500,150],QUESTION,{fontSize:39});ctx.restore();}
  if(u>.64){let q=phase(u,.64,1.02,out);ctx.save();ctx.globalAlpha=q;maskText('Answers you can explore.',960,155,62,q,{align:'center',weight:600});ctx.restore();}
}

const fullFresh=[220,180,1480,853.313];
const nativeActive=[220+1564/2560*1480,180+218/1476*853.313,924/2560*1480,824/1476*853.313];
function transcriptScene(t){
  const u=t-13.75;background(t);
  let p=phase(u,0,.38,out);let box=[880,160,924,824];
  if(p<.97)perspectiveCard(assets['active-transcript'],box,lerp(-Math.PI/2,0,p));
  else card(assets['active-transcript'],box,{alpha:1,fadeBottom:true,shadowAlpha:.18});
  maskText('Read.',140,400,148,phase(u,.05,.40,out),{weight:600});
  maskText('Listen.',140,560,148,phase(u,.24,.59,out),{weight:600,color:C.teal});
  const q=phase(u,.58,.91,out);ctx.save();ctx.globalAlpha=q;
  wave(152,680,450,125,C.teal,7,1,.12*Math.sin(u*8));
  txt('Stay with the conversation.',148,850,36,C.muted,'left','SF Pro',400);ctx.restore();
  // The shown timestamp and highlighted paragraph are from a fresh real app capture.
}

function macScene(t){
  const u=t-15.5;background(t);const p=phase(u,0,.75,ease),end=phase(u,1.13,1.5,ease);
  const app=mixBox(fullFresh,[820,400,280,162],end);
  card(assets['fresh-workspace'],app,{alpha:p*(1-end*.5),radius:lerp(26,34,end),shadowAlpha:.18});
  let box=mixBox([880,160,924,824],nativeActive,p);box=mixBox(box,[840,410,240,214],end);
  if(p<.999)card(assets['active-transcript'],box,{alpha:1-p*.1,fadeBottom:p<.3,shadowAlpha:.18*(1-p)});
  ctx.save();ctx.globalAlpha=1-p;maskText('Read.',140,400-p*50,148,1,{weight:600});maskText('Listen.',140,560-p*50,148,1,{weight:600,color:C.teal});wave(152,680,450,125,C.teal,7);txt('Stay with the conversation.',148,850,36,C.muted);ctx.restore();
  ctx.save();ctx.globalAlpha=1-end;maskText('Made for Mac.',960,113,72,phase(u,.54,.90,out),{align:'center',weight:600});ctx.restore();
}

function ending(t){
  const u=t-17;const p=phase(u,0,.42,ease);background(t);
  const rad=lerp(90,1300,p);ctx.save();ctx.beginPath();ctx.arc(960,510,rad,0,Math.PI*2);ctx.clip();background(t,true);ctx.restore();
  if(p<.4){let q=1-p/.4;card(assets['fresh-workspace'],[820,400,280,162],{alpha:q,radius:34});}
  const q=phase(u,.12,.62,out);ctx.save();ctx.globalAlpha=q;
  wave(720,210+(1-q)*150,480,200,C.paper,9,phase(u,.08,.60,out));ctx.restore();
  maskText('Wavepod',960,574,174,phase(u,.28,.78,out),{align:'center',family:'New York',weight:600,color:C.paper});
  maskText('Read your podcasts. Ask them anything.',960,695,46,phase(u,.46,.96,out),{align:'center',family:'SF Pro',weight:400,color:C.paper});
  const r=phase(u,.65,1.10,out);ctx.save();ctx.globalAlpha=r;
  round(678,780+(1-r)*26,564,82,41);ctx.fillStyle='rgba(244,241,234,.11)';ctx.fill();ctx.strokeStyle='rgba(244,241,234,.23)';ctx.lineWidth=1;ctx.stroke();
  txt('Free for Mac  ·  Open source',960,833+(1-r)*26,31,C.paper,'center','SF Pro',500);
  txt('github.com/concava/wavepod',960,956,29,'#C3D8CE','center','SF Pro',400);ctx.restore();
}

function drawFrame(t){
  ctx.save();t=clamp(t,0,19.9999);
  if(t<3.25)opening(t);else if(t<5.75)linkToApp(t);else if(t<8.5)summaryScene(t);else if(t<10.75)askScene(t);else if(t<13.75)answerScene(t);else if(t<15.5)transcriptScene(t);else if(t<17)macScene(t);else ending(t);
  ctx.restore();
}

async function init(){for(const file of fs.readdirSync(path.join(ROOT,'assets','crops')).filter(f=>f.endsWith('.png'))){assets[path.basename(file,'.png')]=await loadImage(path.join(ROOT,'assets','crops',file));}}
async function preview(){
  const times=[.25,.85,1.35,1.85,2.4,3.24,3.8,4.8,5.5,6.3,7.3,8.49,9.0,10.3,11.2,12.2,13.3,14.3,15.9,16.55,17.4,18.3,19.9];
  const tw=480,th=270;const sheet=createCanvas(1920,Math.ceil(times.length/4)*306);const sc=sheet.getContext('2d');sc.fillStyle='#E7E9E2';sc.fillRect(0,0,sheet.width,sheet.height);
  for(let i=0;i<times.length;i++){drawFrame(times[i]);const png=main.toBuffer('image/png');fs.writeFileSync(path.join(PREVIEW,`frame-${times[i].toFixed(2)}.png`),png);const still=await loadImage(png);let x=(i%4)*480,y=Math.floor(i/4)*306;sc.drawImage(still,x,y,tw,th);sc.font='18px "SF Pro"';sc.fillStyle=C.ink;sc.fillText(`${times[i].toFixed(2)} s`,x+12,y+295);}
  fs.writeFileSync(path.join(PREVIEW,'storyboard.jpg'),sheet.toBuffer('image/jpeg',92));
  // Two dense contact sheets inspect entrances and transitions at quarter-second intervals.
  for(let page=0;page<2;page++){const grid=createCanvas(1920,8*244);const gc=grid.getContext('2d');gc.fillStyle=C.paper;gc.fillRect(0,0,1920,1952);for(let j=0;j<40;j++){let time=page*10+j*.25;drawFrame(time);const still=await loadImage(main.toBuffer('image/png'));let x=j%5*384,y=Math.floor(j/5)*244;gc.drawImage(still,x,y,384,216);gc.font='16px "SF Pro"';gc.fillStyle=C.ink;gc.fillText(time.toFixed(2)+' s',x+10,y+238);}fs.writeFileSync(path.join(PREVIEW,`motion-sheet-${page}.jpg`),grid.toBuffer('image/jpeg',90));}
  console.log('Preview frames and storyboards ready.');
}
async function render({draft=false}={}){
  const fps=draft?30:60;const size=draft?'1280:720':'1920:1080';const output=path.join(OUT,draft?'wavepod-launch-20s-draft.mp4':'wavepod-launch-narrated-20s.mp4');
  const cmd=['-hide_banner','-loglevel','error','-y','-f','rawvideo','-pixel_format','rgba','-video_size','1920x1080','-framerate',String(fps),'-i','-','-i',path.join(ROOT,'audio','wavepod-narrated-mix.wav'),'-map','0:v','-map','1:a','-vf',`scale=${size}:out_color_matrix=bt709:out_range=tv`,'-c:v','libx264','-preset',draft?'veryfast':'slow','-crf',draft?'22':'17','-threads','6','-pix_fmt','yuv420p','-bsf:v','h264_metadata=colour_primaries=1:transfer_characteristics=1:matrix_coefficients=1:video_full_range_flag=0','-c:a','aac','-b:a','256k','-ar','48000','-t','20','-movflags','+faststart','-metadata','title=Wavepod — Read your podcasts','-metadata','comment=Original motion design and music. Real Wavepod app imagery.',output];
  const ff=spawn('ffmpeg',cmd,{stdio:['pipe','inherit','inherit']});let failed=null;ff.on('error',err=>failed=err);
  for(let i=0;i<20*fps;i++){drawFrame(i/fps);if(!ff.stdin.write(main.data()))await once(ff.stdin,'drain');if(i%120===0)console.log(`Rendered ${i}/${20*fps} frames`);if(failed)throw failed;}
  ff.stdin.end();const[code]=await once(ff,'close');if(code!==0)throw new Error(`FFmpeg exit ${code}`);
  drawFrame(18.6);fs.writeFileSync(path.join(OUT,'wavepod-launch-poster.jpg'),main.toBuffer('image/jpeg',95));console.log(`Finished ${output}`);
}

async function run(){await init();if(process.argv.includes('--preview'))await preview();else if(process.argv.includes('--frame')){const t=Number(process.argv[process.argv.indexOf('--frame')+1]);drawFrame(t);fs.writeFileSync(path.join(PREVIEW,`inspect-${t}.png`),main.toBuffer('image/png'));}else await render({draft:process.argv.includes('--draft')});}
if(require.main===module)run().catch(e=>{console.error(e);process.exit(1);});
module.exports={init,drawFrame,main,preview,render};
