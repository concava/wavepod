# Wavepod — narrated launch film

20 seconds, 1920 × 1080 at 60 fps. Revision 3 adds a guide voice, replaces the music with a sparse piano/ambient composition, reduces the mix level, removes two misplaced text highlight overlays, and matches Wavepod’s typography throughout.

## Deliverables

- `exports/wavepod-launch-narrated-20s.mp4`: final H.264/AAC film.
- `exports/wavepod-launch-poster.jpg`: final brand card.
- `audio/narration.srt`: optional timed narration captions.
- `audio/wavepod-narrated-mix.wav`: full 48 kHz, 24-bit stereo mix.
- `audio/wavepod-voiceover.wav`: voice stem.
- `audio/wavepod-soft-piano.wav`: music stem before dialogue ducking.
- `src/film.cjs`: editable deterministic animation.

## Typography

The source of truth is `WavepodKit/Sources/UI/Theme.swift`: `display`, `readingTitle` and `episodeTitle` use the macOS system serif at semibold weight; body, labels and captions use the default system sans serif. The video uses the corresponding installed New York and SF Pro fonts. These replace both Avenir and Baskerville in the previous video. Fonts are referenced from macOS and are not redistributed. The original app screenshots retain their native text.

## Render

Requires macOS, Node.js and FFmpeg on PATH.

```sh
npm install
npm run preview
npm run render
```

The render uses the included audio mix. For an individual still: `node src/film.cjs --frame 12.5`.

## Voice and music

Narration uses the stock `af_heart` synthetic voice with [Kokoro ONNX](https://github.com/thewh1teagle/kokoro-onnx). It is not a clone of a real person. Model files were downloaded from the project’s published release and are stored outside this deliverable. Kokoro ONNX is MIT-licensed and its model is Apache-2.0. The seven short phrases are individually timed to the product scenes; the script and cue list are included.

The backing track is an original 96 BPM felt-key and ambient composition, synthesized without third-party recordings or samples. There are no drum fills or loud transition hits. Music starts at −32 LUFS and ducks a further 5 dB during each phrase; the final mix targets −20 LUFS, about 3 dB quieter than revision 2. Measured export values are in `verification.json`.

To rebuild audio, install `kokoro-onnx`, `soundfile`, `numpy` and `scipy` in a Python environment, then run:

```sh
python audio/create_narration.py --model-dir /path/to/kokoro-models
python audio/create_mix.py
```

The model directory must contain `kokoro-v1.0.onnx` and `voices-v1.0.bin`, as documented by the upstream project. Existing WAV stems are included so re-rendering the video does not require model downloads.

## Product imagery

The answer, active transcript and final workspace originate from captures of the running Wavepod app. The summary view uses the supplied product screenshot. The input animation is staged; the answer is a captured existing answer. The transcript represents a separate playback moment. Crop origins and rectangles are recorded in `assets/crops/manifest.json`. Full original captures remain in the sibling `launch-v2/assets` folder in the workspace; the render is self-contained using the included crops.

The two manually drawn emphasis rectangles shown in the feedback screenshots have been removed. The actual app’s active-transcript background remains part of its capture.
